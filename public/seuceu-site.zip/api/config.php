<?php
/**
 * Céu Criativa - Configuração do Servidor HostGator
 *
 * Este arquivo contém as configurações da API para execução no Apache / PHP da HostGator.
 */

// Chave da API Google Gemini
// Você pode definir como variável de ambiente no cPanel ou deixar a chave abaixo:
$gemini_key = getenv('GEMINI_API_KEY') ?: 'AIzaSyC4f24-VLVunTpzqtP3aFolpXLIRqyYuoQ';
define('GEMINI_API_KEY', $gemini_key);

// Diretório de Uploads
define('UPLOADS_DIR', __DIR__ . '/../uploads');

// URL Base pública de uploads
define('UPLOADS_URL', '/uploads');

// Timezone
date_default_timezone_set('America/Sao_Paulo');
