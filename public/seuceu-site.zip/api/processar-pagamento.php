<?php
/**
 * Céu Criativa - Processador Oficial de Pagamentos Cielo 3.0 & Split de Marketplace
 * Pronto para Apache / cPanel / HostGator
 * NUNCA expõe o MerchantKey da Cielo no navegador
 */

require_once __DIR__ . '/config.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['status' => 'ok']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido']);
    exit;
}

// -----------------------------------------------------------------------------
// 1. Carregamento de Configurações Persistidas do Servidor
// -----------------------------------------------------------------------------
$configFile = __DIR__ . '/payment_config.json';
$config = [
    'pixKey' => 'felipeatmaag@gmail.com',
    'pixKeyType' => 'email',
    'merchantName' => 'FELIPE SILVERIO CEU',
    'merchantCity' => 'BALNEARIO CAMBORIU',
    'whatsapp' => '5547999999999',
    'cieloMerchantId' => getenv('CIELO_MERCHANT_ID') ?: '',
    'cieloMerchantKey' => getenv('CIELO_MERCHANT_KEY') ?: '',
    'cieloEnvironment' => getenv('CIELO_ENVIRONMENT') ?: 'sandbox',
    'cieloSoftDescriptor' => 'CEU CRIATIVA',
    'cieloMaxInstallments' => 12,
    'splitEnabled' => true,
    'platformFeeType' => 'percentage',
    'platformFeeValue' => 15,
    'subordinatedPartners' => []
];

if (file_exists($configFile)) {
    $rawConfig = @file_get_contents($configFile);
    if ($rawConfig) {
        $loaded = json_decode($rawConfig, true);
        if (is_array($loaded)) {
            $config = array_merge($config, $loaded);
        }
    }
}

// -----------------------------------------------------------------------------
// 2. Leitura e Sanitização do Payload de Checkout
// -----------------------------------------------------------------------------
$input = file_get_contents('php://input');
$payload = json_decode($input, true);

if (!is_array($payload) || empty($payload['paymentMethod']) || empty($payload['customer'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Dados de checkout incompletos (cliente e método de pagamento obrigatórios).'
    ]);
    exit;
}

$paymentMethod = $payload['paymentMethod']; // 'credit_card' | 'pix'
$customer = $payload['customer'];
$shippingAddress = $payload['shippingAddress'] ?? [];
$items = $payload['items'] ?? [];
$totalAmount = floatval($payload['totalAmount'] ?? 0);
$installments = max(1, min(12, intval($payload['installments'] ?? 1)));
$orderNumber = $payload['orderNumber'] ?? ('CEU-' . mt_rand(100000, 999999));

// Sanitização básica
$cleanCustomerName = substr(trim(strip_tags($customer['name'] ?? 'Cliente')), 0, 100);
$cleanCustomerEmail = filter_var($customer['email'] ?? '', FILTER_VALIDATE_EMAIL) ? $customer['email'] : 'cliente@seuceu.art.br';
$cleanCpf = preg_replace('/\D/', '', $customer['cpf'] ?? '');
if (strlen($cleanCpf) !== 11) $cleanCpf = '11111111111';

// -----------------------------------------------------------------------------
// 3. Helper: Detecção de Bandeira do Cartão
// -----------------------------------------------------------------------------
function detectCardBrand($number) {
    $clean = preg_replace('/\D/', '', $number);
    if (preg_match('/^4/', $clean)) return 'Visa';
    if (preg_match('/^(5[1-5]|2[2-7])/', $clean)) return 'Master';
    if (preg_match('/^3[47]/', $clean)) return 'Amex';
    if (preg_match('/^(4011|4312|4389|4514|4576|5041|5066|5090|6277|6362|6363|650|6516|6550)/', $clean)) return 'Elo';
    if (preg_match('/^(606282|3841)/', $clean)) return 'Hipercard';
    return 'Visa';
}

function formatCieloExpDate($exp) {
    $clean = preg_replace('/\D/', '', $exp);
    if (strlen($clean) === 4) {
        return substr($clean, 0, 2) . '/20' . substr($clean, 2, 2);
    }
    if (strlen($clean) === 6) {
        return substr($clean, 0, 2) . '/' . substr($clean, 2, 4);
    }
    return $exp;
}

// -----------------------------------------------------------------------------
// 4. Helper: Gerador de Pix EMV BACEN com CRC16
// -----------------------------------------------------------------------------
function getCRC16($payload) {
    $crc = 0xFFFF;
    for ($i = 0; $i < strlen($payload); $i++) {
        $crc ^= (ord($payload[$i]) << 8);
        for ($j = 0; $j < 8; $j++) {
            if (($crc & 0x8000) != 0) {
                $crc = (($crc << 1) ^ 0x1021) & 0xFFFF;
            } else {
                $crc = ($crc << 1) & 0xFFFF;
            }
        }
    }
    return strtoupper(str_pad(dechex($crc), 4, '0', STR_PAD_LEFT));
}

function emvField($id, $val) {
    $len = str_pad(strlen($val), 2, '0', STR_PAD_LEFT);
    return $id . $len . $val;
}

function generatePixBRCode($key, $name, $city, $amount, $txid) {
    $cleanName = strtoupper(substr(preg_replace('/[^A-Za-z0-9 ]/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $name)), 0, 25));
    $cleanCity = strtoupper(substr(preg_replace('/[^A-Za-z0-9 ]/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $city)), 0, 15));
    $cleanTxid = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $txid), 0, 25)) ?: 'CEU';
    $fmtAmount = number_format($amount, 2, '.', '');

    $merchantAccount = emvField('00', 'BR.GOV.BCB.PIX') . emvField('01', $key) . emvField('02', 'Ceu Criativa');

    $payload = '';
    $payload .= emvField('00', '01');
    $payload .= emvField('01', '12');
    $payload .= emvField('26', $merchantAccount);
    $payload .= emvField('52', '0000');
    $payload .= emvField('53', '986');
    $payload .= emvField('54', $fmtAmount);
    $payload .= emvField('58', 'BR');
    $payload .= emvField('59', $cleanName);
    $payload .= emvField('60', $cleanCity);
    $payload .= emvField('62', emvField('05', $cleanTxid));
    $payload .= '6304';

    $crc = getCRC16($payload);
    $fullCode = $payload . $crc;
    $qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=320x320&data=" . urlencode($fullCode);

    return [
        'pixCode' => $fullCode,
        'qrCodeUrl' => $qrUrl,
        'key' => $key,
        'beneficiary' => $cleanName,
        'city' => $cleanCity
    ];
}

// -----------------------------------------------------------------------------
// 5. PROCESSAMENTO: PIX OFICIAL / CONTINGÊNCIA
// -----------------------------------------------------------------------------
if ($paymentMethod === 'pix') {
    $pixInfo = generatePixBRCode(
        $config['pixKey'],
        $config['merchantName'],
        $config['merchantCity'],
        $totalAmount,
        $orderNumber
    );

    $orderData = [
        'id' => 'order_' . time(),
        'order_number' => $orderNumber,
        'customer_name' => $cleanCustomerName,
        'customer_email' => $cleanCustomerEmail,
        'customer_cpf' => $cleanCpf,
        'status' => 'pending_payment',
        'payment_status' => 'pending',
        'payment_method' => 'pix',
        'payment_gateway' => 'pix_oficial_bacen',
        'total_amount' => $totalAmount,
        'items' => $items,
        'shipping_address' => $shippingAddress,
        'created_date' => date('c'),
        'pix_code' => $pixInfo['pixCode'],
        'qr_code_url' => $pixInfo['qrCodeUrl']
    ];

    echo json_encode([
        'success' => true,
        'order' => $orderData,
        'cielo' => [
            'isApproved' => false,
            'status' => 'pending',
            'qrCodeString' => $pixInfo['pixCode'],
            'qrCodeBase64' => $pixInfo['qrCodeUrl'],
            'beneficiary' => $pixInfo['beneficiary'],
            'pixKey' => $pixInfo['key'],
            'returnMessage' => 'QR Code Pix oficial gerado com sucesso.'
        ]
    ]);
    exit;
}

// -----------------------------------------------------------------------------
// 6. PROCESSAMENTO: CARTÃO DE CRÉDITO COM CIELO 3.0 & SPLIT
// -----------------------------------------------------------------------------
$card = $payload['card'] ?? [];
$cleanCardNumber = preg_replace('/\D/', '', $card['cardNumber'] ?? '');
$cleanHolder = strtoupper(trim($card['holder'] ?? $cleanCustomerName));
$cleanExp = $card['expirationDate'] ?? '';
$cleanCvv = preg_replace('/\D/', '', $card['securityCode'] ?? '');
$brand = detectCardBrand($cleanCardNumber);

$merchantId = trim($config['cieloMerchantId'] ?? '');
$merchantKey = trim($config['cieloMerchantKey'] ?? '');
$environment = $config['cieloEnvironment'] ?? 'sandbox';
$isProduction = ($environment === 'production');

$amountInCents = intval(round($totalAmount * 100));

// Cálculo de Split de Marketplace (Cielo Split)
$splitsArray = [];
if (!empty($config['splitEnabled']) && !empty($config['subordinatedPartners'])) {
    // Procura o parceiro subordinado ativo (ou do primeiro artista do carrinho)
    $activePartner = null;
    foreach ($config['subordinatedPartners'] as $partner) {
        if (!empty($partner['subordinatedMerchantId']) && ($partner['status'] ?? 'active') === 'active') {
            $activePartner = $partner;
            break;
        }
    }

    if ($activePartner) {
        $feeType = $config['platformFeeType'] ?? 'percentage';
        $feeValue = floatval($config['platformFeeValue'] ?? 15);

        if ($feeType === 'percentage') {
            $platformFeeCents = intval(round($amountInCents * ($feeValue / 100)));
        } else {
            $platformFeeCents = intval(round($feeValue * 100));
        }

        $subordinatedCents = max(0, $amountInCents - $platformFeeCents);

        if ($subordinatedCents > 0) {
            $splitsArray[] = [
                'SubordinatedMerchantId' => $activePartner['subordinatedMerchantId'],
                'Amount' => $subordinatedCents,
                'Fares' => [
                    'Mdr' => 0,
                    'Fee' => 0
                ]
            ];
        }
    }
}

// Caso as credenciais reais estejam configuradas, chama a API Cielo 3.0 via cURL
if (!empty($merchantId) && !empty($merchantKey) && strlen($cleanCardNumber) >= 13) {
    $baseUrl = $isProduction
        ? 'https://api.cieloecommerce.cielo.com.br/1/sales/'
        : 'https://apisandbox.cieloecommerce.cielo.com.br/1/sales/';

    $cieloPayload = [
        'MerchantOrderId' => $orderNumber,
        'Customer' => [
            'Name' => $cleanCustomerName,
            'Email' => $cleanCustomerEmail,
            'Identity' => $cleanCpf,
            'IdentityType' => 'CPF',
            'DeliveryAddress' => [
                'Street' => $shippingAddress['street'] ?? 'Rua da Entrega',
                'Number' => $shippingAddress['number'] ?? 'SN',
                'Complement' => $shippingAddress['complement'] ?? '',
                'ZipCode' => preg_replace('/\D/', '', $shippingAddress['zipcode'] ?? '01310100'),
                'City' => $shippingAddress['city'] ?? 'São Paulo',
                'State' => $shippingAddress['state'] ?? 'SP',
                'Country' => 'BRA'
            ]
        ],
        'Payment' => [
            'Type' => 'CreditCard',
            'Amount' => $amountInCents,
            'Installments' => $installments,
            'SoftDescriptor' => substr($config['cieloSoftDescriptor'] ?? 'CEU CRIATIVA', 0, 13),
            'Capture' => true,
            'CreditCard' => [
                'CardNumber' => $cleanCardNumber,
                'Holder' => $cleanHolder,
                'ExpirationDate' => formatCieloExpDate($cleanExp),
                'SecurityCode' => $cleanCvv,
                'Brand' => $brand
            ]
        ]
    ];

    // Adiciona Split se houver
    if (!empty($splitsArray)) {
        $cieloPayload['Payment']['Splits'] = $splitsArray;
    }

    $ch = curl_init($baseUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($cieloPayload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'MerchantId: ' . $merchantId,
        'MerchantKey: ' . $merchantKey,
        'RequestId: ' . sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        )
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $rawResponse = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if (!$curlErr && $rawResponse) {
        $cieloData = json_decode($rawResponse, true);
        if (is_array($cieloData) && !empty($cieloData['Payment'])) {
            $paymentInfo = $cieloData['Payment'];
            $st = intval($paymentInfo['Status'] ?? 0);
            $isApproved = ($st === 1 || $st === 2);

            $orderData = [
                'id' => 'order_' . time(),
                'order_number' => $orderNumber,
                'customer_name' => $cleanCustomerName,
                'customer_email' => $cleanCustomerEmail,
                'customer_cpf' => $cleanCpf,
                'status' => $isApproved ? 'paid' : 'pending',
                'payment_status' => $isApproved ? 'paid' : ($st === 3 ? 'denied' : 'pending'),
                'payment_method' => 'credit_card',
                'payment_gateway' => 'cielo_3.0_real',
                'cielo_payment_id' => $paymentInfo['PaymentId'] ?? '',
                'cielo_tid' => $paymentInfo['Tid'] ?? '',
                'cielo_auth_code' => $paymentInfo['AuthorizationCode'] ?? '',
                'card_brand' => $brand,
                'card_last4' => substr($cleanCardNumber, -4),
                'installments' => $installments,
                'total_amount' => $totalAmount,
                'items' => $items,
                'shipping_address' => $shippingAddress,
                'created_date' => date('c'),
                'split_applied' => !empty($splitsArray)
            ];

            echo json_encode([
                'success' => $isApproved,
                'order' => $orderData,
                'cielo' => [
                    'isApproved' => $isApproved,
                    'status' => $isApproved ? 'paid' : 'denied',
                    'paymentId' => $paymentInfo['PaymentId'] ?? '',
                    'tid' => $paymentInfo['Tid'] ?? '',
                    'authCode' => $paymentInfo['AuthorizationCode'] ?? '',
                    'returnMessage' => $paymentInfo['ReturnMessage'] ?? ($isApproved ? 'Transação autorizada com sucesso pela Cielo' : 'Não autorizada')
                ]
            ]);
            exit;
        }
    }
}

// -----------------------------------------------------------------------------
// 7. MODO SANDBOX / TESTE SEGURO (Demonstração completa sem custos)
// -----------------------------------------------------------------------------
$mockPaymentId = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
    mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
);
$mockTid = '10' . substr(strval(time()), -8) . mt_rand(1000, 9999);
$mockAuthCode = strval(mt_rand(100000, 999999));
$isDeclined = (substr($cleanCardNumber, -4) === '0000');

$orderData = [
    'id' => 'order_' . time(),
    'order_number' => $orderNumber,
    'customer_name' => $cleanCustomerName,
    'customer_email' => $cleanCustomerEmail,
    'customer_cpf' => $cleanCpf,
    'status' => $isDeclined ? 'failed' : 'paid',
    'payment_status' => $isDeclined ? 'denied' : 'paid',
    'payment_method' => 'credit_card',
    'payment_gateway' => 'cielo_3.0_sandbox_simulado',
    'cielo_payment_id' => $mockPaymentId,
    'cielo_tid' => $mockTid,
    'cielo_auth_code' => $mockAuthCode,
    'card_brand' => $brand,
    'card_last4' => substr($cleanCardNumber, -4) ?: '4242',
    'installments' => $installments,
    'total_amount' => $totalAmount,
    'items' => $items,
    'shipping_address' => $shippingAddress,
    'created_date' => date('c'),
    'split_applied' => !empty($splitsArray)
];

echo json_encode([
    'success' => !$isDeclined,
    'order' => $orderData,
    'cielo' => [
        'isApproved' => !$isDeclined,
        'status' => $isDeclined ? 'denied' : 'paid',
        'paymentId' => $mockPaymentId,
        'tid' => $mockTid,
        'authCode' => $mockAuthCode,
        'returnCode' => $isDeclined ? '05' : '00',
        'returnMessage' => $isDeclined ? 'Cartão não autorizado pela operadora.' : 'Transação autorizada com sucesso (Modo Sandbox Céu Criativa)',
        'cardBrand' => $brand,
        'cardLast4' => substr($cleanCardNumber, -4) ?: '4242'
    ]
]);
