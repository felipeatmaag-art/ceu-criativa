<?php
/**
 * Céu Criativa - Backend PHP para HostGator (Apache / cPanel)
 * Processa requisições de IA (Google Gemini), Uploads e API REST.
 */

require_once __DIR__ . '/config.php';

// Headers CORS e JSON
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=utf-8");

// Trata preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['status' => 'ok']);
    exit;
}

// Garante que o diretório de uploads exista
if (!is_dir(UPLOADS_DIR)) {
    @mkdir(UPLOADS_DIR, 0755, true);
}

// Extrai a rota da requisição
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
// Remove /api ou /api/index.php do início
$route = preg_replace('#^.*?api(/index\.php)?#', '', $requestUri);
$route = '/' . ltrim($route, '/');
$method = $_SERVER['REQUEST_METHOD'];

// Helper para ler body JSON
function getJsonBody() {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// Helper para fazer requisição HTTP via cURL
function callGoogleGeminiApi($url, $payload) {
    $ch = curl_init($url);
    $json = json_encode($payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'User-Agent: aistudio-build-hostgator'
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 40);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $res = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        return ['error' => 'Erro de conexão cURL com a API Gemini: ' . $curlErr];
    }

    $decoded = json_decode($res, true);
    if ($httpCode !== 200 || !empty($decoded['error'])) {
        $msg = !empty($decoded['error']['message']) ? $decoded['error']['message'] : 'Código de erro HTTP ' . $httpCode;
        return ['error' => 'Erro retornado pela API Gemini (' . $msg . ')'];
    }

    return $decoded;
}

// -------------------------------------------------------------------------
// 1. Health Check
// -------------------------------------------------------------------------
if ($route === '/health' || $route === '/' || $route === '') {
    echo json_encode([
        'status' => 'ok',
        'service' => 'ceu-criativa-hostgator-php',
        'timestamp' => time(),
        'uploads_writable' => is_writable(UPLOADS_DIR)
    ]);
    exit;
}

// -------------------------------------------------------------------------
// Rotas de Pagamento & Gateway Cielo (HostGator Apache / cPanel)
// -------------------------------------------------------------------------
if ($route === '/payment/config' || $route === '/config-pagamento') {
    require __DIR__ . '/config-pagamento.php';
    exit;
}

if ($route === '/processar-pagamento' || $route === '/cielo/checkout' || $route === '/payment/checkout') {
    require __DIR__ . '/processar-pagamento.php';
    exit;
}

// -------------------------------------------------------------------------
// 2. Upload de Arquivos (/api/upload)
// -------------------------------------------------------------------------
if ($route === '/upload' && $method === 'POST') {
    // Caso 1: Multipart File Upload
    if (!empty($_FILES['file'])) {
        $file = $_FILES['file'];
        $cleanName = time() . '-' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $file['name']);
        $targetPath = UPLOADS_DIR . '/' . $cleanName;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            $url = UPLOADS_URL . '/' . $cleanName;
            echo json_encode([
                'file_url' => $url,
                'url' => $url,
                'filename' => $cleanName,
                'size' => $file['size']
            ]);
            exit;
        }
    }

    // Caso 2: JSON com Base64
    $body = getJsonBody();
    if (!empty($body['data'])) {
        $dataUrl = $body['data'];
        $filename = !empty($body['filename']) ? $body['filename'] : 'upload.png';
        $cleanName = time() . '-' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
        $targetPath = UPLOADS_DIR . '/' . $cleanName;

        if (preg_match('/^data:([^;]+);base64,(.+)$/', $dataUrl, $matches)) {
            $binary = base64_decode($matches[2]);
            if (@file_put_contents($targetPath, $binary)) {
                $url = UPLOADS_URL . '/' . $cleanName;
                echo json_encode([
                    'file_url' => $url,
                    'url' => $url,
                    'filename' => $cleanName
                ]);
                exit;
            }
        }

        // Se falhar a gravação em disco por permissão, retorna o próprio Data URL com segurança
        echo json_encode([
            'file_url' => $dataUrl,
            'url' => $dataUrl,
            'filename' => $cleanName
        ]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['error' => 'Nenhum arquivo enviado para upload.']);
    exit;
}

// -------------------------------------------------------------------------
// 3. Geração de Imagem com Gemini (/api/gemini/generate-image)
// -------------------------------------------------------------------------
if ($route === '/gemini/generate-image' && $method === 'POST') {
    $body = getJsonBody();
    $rawPrompt = !empty($body['prompt']) ? trim($body['prompt']) : '';

    if (empty($rawPrompt)) {
        http_response_code(400);
        echo json_encode(['error' => 'Prompt é obrigatório para geração de imagem.']);
        exit;
    }

    // Sanitização de prompt para focar puramente em vetor 2D e evitar mockups de camiseta
    $cleanPrompt = preg_replace('/\b(camiseta|camisa|blusa|baby\s*look|moletom|t-?shirt|regata|polo|jaqueta|vestu[aá]rio)\s+preta\s+(de|com|do|da)?\b/i', 'arte gráfica vetorial em alto contraste com ', $rawPrompt);
    $cleanPrompt = preg_replace('/\b(camiseta|camisa|blusa|baby\s*look|moletom|t-?shirt|regata|polo|jaqueta|vestu[aá]rio)\s+branca\s+(de|com|do|da)?\b/i', 'arte gráfica vetorial com ', $cleanPrompt);
    $cleanPrompt = preg_replace('/\b(camiseta|camisa|blusa|baby\s*look|moletom|t-?shirt|regata|polo|jaqueta|vestu[aá]rio)\s+(de|com|do|da)?\b/i', 'ilustração vetorial de ', $cleanPrompt);
    $cleanPrompt = preg_replace('/\b(estampa|desenho|arte)\s+(para|de|em|pra)\s+(camiseta|camisa|blusa|roupa|moletom|t-?shirt)\b/i', 'ilustração gráfica vetorial isolada', $cleanPrompt);
    $cleanPrompt = preg_replace('/\b(em\s+uma|numa|na|no)\s+(camiseta|camisa|blusa|roupa|moletom|t-?shirt)\b/i', 'em formato decalque adesivo', $cleanPrompt);
    $cleanPrompt = preg_replace('/\b(mockup|gola|manga|mangas|tecido|cabide|manequim|pessoa vestindo)\b/i', '', $cleanPrompt);
    $cleanPrompt = preg_replace('/\b(camisetas|camiseta|camisas|camisa|t-?shirts?|roupas|roupa|moletom)\b/i', 'arte gráfica', $cleanPrompt);

    $isDark = !empty($body['colorName']) && preg_match('/black|preto|preta|navy|marinho|dark|escuro|escura|chumbo/i', $body['colorName']);

    $finalPrompt = "Pure standalone 2D vector graphic design decal sticker, isolated screenprint graphic illustration, sharp clean crisp contour edges, centered on solid flat vibrant green background #00FF00. Subject: " . $cleanPrompt . ". Style: High quality vector art, clean sharp lines, screenprint decal badge aesthetic, pure flat 2D graphic asset file only.";
    if ($isDark) {
        $finalPrompt .= "\nColor Contrast: High-contrast bright vivid palette (pure white, cream, vibrant light tones, bold highlights) designed to pop with brilliant contrast on dark surfaces.";
    }
    $finalPrompt .= "\nChroma Background: Pure solid flat uniform green #00FF00 background with sharp cutout edges, internal letter holes cut out showing continuous #00FF00 green.";

    $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite-image:generateContent?key=" . GEMINI_API_KEY;
    $payload = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $finalPrompt]
                ]
            ]
        ]
    ];

    $response = callGoogleGeminiApi($endpoint, $payload);

    if (isset($response['error'])) {
        http_response_code(500);
        echo json_encode(['error' => $response['error']]);
        exit;
    }

    $inlineData = null;
    if (!empty($response['candidates'][0]['content']['parts'])) {
        foreach ($response['candidates'][0]['content']['parts'] as $part) {
            if (!empty($part['inlineData']['data'])) {
                $inlineData = $part['inlineData'];
                break;
            }
        }
    }

    if (!$inlineData) {
        http_response_code(500);
        echo json_encode(['error' => 'A IA não retornou imagem para este prompt. Tente formular com outras palavras.']);
        exit;
    }

    $mime = !empty($inlineData['mimeType']) ? $inlineData['mimeType'] : 'image/jpeg';
    $ext = strpos($mime, 'png') !== false ? 'png' : 'jpg';
    $binary = base64_decode($inlineData['data']);
    $filename = 'gemini-gen-' . time() . '-' . substr(md5(uniqid()), 0, 6) . '.' . $ext;
    $targetPath = UPLOADS_DIR . '/' . $filename;

    if (@file_put_contents($targetPath, $binary)) {
        $url = UPLOADS_URL . '/' . $filename;
        echo json_encode(['url' => $url]);
        exit;
    }

    // Se gravação local em disco falhar por permissões na HostGator, retorna data URL inline
    $dataUri = 'data:' . $mime . ';base64,' . $inlineData['data'];
    echo json_encode(['url' => $dataUri]);
    exit;
}

// -------------------------------------------------------------------------
// 4. Aprimorar Prompt com Gemini (/api/gemini/enhance-prompt)
// -------------------------------------------------------------------------
if ($route === '/gemini/enhance-prompt' && $method === 'POST') {
    $body = getJsonBody();
    $userPrompt = !empty($body['prompt']) ? trim($body['prompt']) : '';
    $style = !empty($body['style']) ? $body['style'] : '';
    $productColor = !empty($body['productColor']) ? $body['productColor'] : '';

    if (empty($userPrompt)) {
        echo json_encode(['enhancedPrompt' => $userPrompt]);
        exit;
    }

    $systemInstruction = "Você é um especialista em design gráfico e estampas artísticas para vestuário e produtos criativos da Céu Criativa. " .
        "Transforme a ideia do usuário em um prompt visual rico, detalhado, com foco exclusivo na arte gráfica 2D/vetorial. " .
        "NÃO inclua palavras como modelo, cabide, camiseta ou roupa vestida. Foco apenas na ilustração e suas cores. " .
        "Retorne APENAS o prompt enriquecido, sem saudações ou explicações.";

    $promptText = "Estilo desejado: {$style}. Cor do fundo/produto: {$productColor}. Ideia do usuário: \"{$userPrompt}\". Enriqueça este prompt:";

    $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=" . GEMINI_API_KEY;
    $payload = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $systemInstruction . "\n\n" . $promptText]
                ]
            ]
        ]
    ];

    $response = callGoogleGeminiApi($endpoint, $payload);

    if (isset($response['error']) || empty($response['candidates'][0]['content']['parts'][0]['text'])) {
        // Fallback gracefully
        echo json_encode(['enhancedPrompt' => $userPrompt]);
        exit;
    }

    $enhanced = trim($response['candidates'][0]['content']['parts'][0]['text']);
    echo json_encode(['enhancedPrompt' => $enhanced]);
    exit;
}

// -------------------------------------------------------------------------
// 5. Consulta LLM Geral (/api/gemini/invoke-llm)
// -------------------------------------------------------------------------
if ($route === '/gemini/invoke-llm' && $method === 'POST') {
    $body = getJsonBody();
    $prompt = !empty($body['prompt']) ? $body['prompt'] : '';

    $endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=" . GEMINI_API_KEY;
    $payload = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $prompt]
                ]
            ]
        ]
    ];

    $response = callGoogleGeminiApi($endpoint, $payload);
    $result = !empty($response['candidates'][0]['content']['parts'][0]['text']) ? $response['candidates'][0]['content']['parts'][0]['text'] : '';

    echo json_encode(['result' => $result]);
    exit;
}

// -------------------------------------------------------------------------
// 6. Entidades CRUD (/api/entities/{name} e sub-rotas)
// -------------------------------------------------------------------------
if (preg_match('#^/entities/([a-zA-Z0-9_-]+)(?:/(.*))?#', $route, $matches)) {
    $entityName = $matches[1];
    $subPath = !empty($matches[2]) ? $matches[2] : '';

    $dataFile = __DIR__ . '/../../data/entities.json';
    if (!file_exists($dataFile)) {
        $dataFile = __DIR__ . '/../data/entities.json';
    }
    if (!file_exists($dataFile)) {
        $dataFile = __DIR__ . '/data/entities.json';
    }

    $store = [];
    if (file_exists($dataFile)) {
        $store = json_decode(file_get_contents($dataFile), true) ?: [];
    }
    if (!isset($store['data'])) {
        $store['data'] = [];
    }
    if (!isset($store['data'][$entityName])) {
        $store['data'][$entityName] = [];
    }

    // 6.1 Delete Many / Bulk Delete
    if (($subPath === 'delete-many' || $subPath === 'bulk-delete') && $method === 'POST') {
        $body = getJsonBody();
        $ids = !empty($body['ids']) ? (array)$body['ids'] : [];
        $initialCount = count($store['data'][$entityName]);

        if (in_array('all', $ids) || in_array('*', $ids) || !empty($body['all'])) {
            $store['data'][$entityName] = [];
        } else {
            $idSet = array_flip(array_map('strval', $ids));
            $store['data'][$entityName] = array_values(array_filter($store['data'][$entityName], function($item) use ($idSet) {
                return !isset($idSet[strval($item['id'] ?? '')]);
            }));
        }

        @file_put_contents($dataFile, json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $removed = $initialCount - count($store['data'][$entityName]);
        echo json_encode(['success' => true, 'count' => $removed]);
        exit;
    }

    // 6.2 Update Many
    if (($subPath === 'update-many' || $subPath === 'bulk-update') && $method === 'POST') {
        $body = getJsonBody();
        $ids = !empty($body['ids']) ? array_flip(array_map('strval', (array)$body['ids'])) : [];
        $patch = !empty($body['data']) ? (array)$body['data'] : [];

        foreach ($store['data'][$entityName] as &$item) {
            if (isset($ids[strval($item['id'] ?? '')])) {
                $item = array_merge($item, $patch, ['updated_date' => date('c')]);
            }
        }
        unset($item);

        @file_put_contents($dataFile, json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode(['success' => true]);
        exit;
    }

    // 6.3 Single Item DELETE
    if ($method === 'DELETE' && $subPath !== '') {
        $deleteId = strval($subPath);
        $initialCount = count($store['data'][$entityName]);
        $store['data'][$entityName] = array_values(array_filter($store['data'][$entityName], function($item) use ($deleteId) {
            return strval($item['id'] ?? '') !== $deleteId;
        }));
        @file_put_contents($dataFile, json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode(['success' => true]);
        exit;
    }

    // 6.4 Single Item PUT
    if ($method === 'PUT' && $subPath !== '') {
        $updateId = strval($subPath);
        $patch = getJsonBody();
        $found = false;
        foreach ($store['data'][$entityName] as &$item) {
            if (strval($item['id'] ?? '') === $updateId) {
                $item = array_merge($item, $patch, ['id' => $updateId, 'updated_date' => date('c')]);
                $found = true;
                echo json_encode($item);
                break;
            }
        }
        unset($item);
        if ($found) {
            @file_put_contents($dataFile, json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            exit;
        }
        http_response_code(404);
        echo json_encode(['error' => 'Item não encontrado']);
        exit;
    }

    // 6.5 Create POST
    if ($method === 'POST' && $subPath === '') {
        $newItem = getJsonBody();
        if (empty($newItem['id'])) {
            $newItem['id'] = 'ent_' . time() . '_' . substr(md5(uniqid()), 0, 5);
        }
        $newItem['created_date'] = date('c');
        $newItem['updated_date'] = date('c');
        array_unshift($store['data'][$entityName], $newItem);
        @file_put_contents($dataFile, json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode($newItem);
        exit;
    }

    // 6.6 List/Filter GET
    if ($method === 'GET') {
        if ($subPath !== '') {
            foreach ($store['data'][$entityName] as $item) {
                if (strval($item['id'] ?? '') === $subPath) {
                    echo json_encode($item);
                    exit;
                }
            }
            http_response_code(404);
            echo json_encode(['error' => 'Item não encontrado']);
            exit;
        }

        $records = $store['data'][$entityName];
        echo json_encode(array_values($records));
        exit;
    }
}

// -------------------------------------------------------------------------
// 7. Funções Financeiras e Repasses Pix (/api/functions/*)
// -------------------------------------------------------------------------
if ($route === '/functions/getArtistFinancialSummary' && $method === 'POST') {
    $dataFile = __DIR__ . '/../../data/entities.json';
    if (!file_exists($dataFile)) $dataFile = __DIR__ . '/../data/entities.json';
    if (!file_exists($dataFile)) $dataFile = __DIR__ . '/data/entities.json';
    
    $store = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];
    $orders = !empty($store['data']['Order']) ? $store['data']['Order'] : [];
    $users = !empty($store['data']['User']) ? $store['data']['User'] : [];
    $payouts = !empty($store['data']['PayoutRequest']) ? $store['data']['PayoutRequest'] : [];
    
    $body = getJsonBody();
    $scope = !empty($body['scope']) ? $body['scope'] : '';
    
    $paidOrders = array_filter($orders, function($o) {
        $st = $o['status'] ?? '';
        $pst = $o['payment_status'] ?? '';
        return $st === 'paid' || $pst === 'paid' || $st === 'delivered' || $st === 'completed';
    });
    $pendingOrders = array_filter($orders, function($o) {
        $st = $o['status'] ?? '';
        return $st === 'pending' || $st === 'pending_payment';
    });
    
    if ($scope === 'platform') {
        $grossSales = 0;
        $totalCommissions = 0;
        $baseCosts = 0;
        $artistMap = [];
        
        foreach ($paidOrders as $order) {
            $orderTotal = floatval($order['total_amount'] ?? 0);
            $grossSales += $orderTotal;
            $baseCosts += $orderTotal * 0.45;
            
            foreach (($order['items'] ?? []) as $item) {
                $itemPrice = floatval($item['price'] ?? 0) * intval($item['quantity'] ?? 1);
                $artistId = $item['artist_id'] ?? ($item['created_by_id'] ?? 'felipe_silverio');
                $artistName = $item['artist_name'] ?? ($item['created_by'] ?? 'Felipe Silvério');
                $commRate = floatval($item['commission_rate'] ?? 25);
                $commAmount = ($itemPrice * $commRate) / 100;
                $totalCommissions += $commAmount;
                
                if (!isset($artistMap[$artistId])) {
                    $pixKey = '';
                    $email = '';
                    foreach ($users as $u) {
                        if (($u['id'] ?? '') === $artistId || ($u['name'] ?? '') === $artistName) {
                            $pixKey = $u['pix_key'] ?? '';
                            $email = $u['email'] ?? '';
                            break;
                        }
                    }
                    $artistMap[$artistId] = [
                        'artistId' => $artistId,
                        'artistName' => $artistName,
                        'sales' => 0,
                        'commission' => 0,
                        'pixKey' => $pixKey,
                        'email' => $email
                    ];
                }
                $artistMap[$artistId]['sales'] += intval($item['quantity'] ?? 1);
                $artistMap[$artistId]['commission'] += $commAmount;
            }
        }
        
        $totalProfit = max(0, $grossSales - $totalCommissions - $baseCosts);
        $salesCount = count($paidOrders);
        $averageTicket = $salesCount > 0 ? $grossSales / $salesCount : 0;
        
        $payoutList = array_map(function($p) {
            return [
                'id' => $p['id'] ?? '',
                'artistId' => $p['artist_id'] ?? '',
                'artistName' => $p['artist_name'] ?? '',
                'artistEmail' => $p['artist_email'] ?? '',
                'pixKey' => $p['pix_key'] ?? '',
                'amount' => floatval($p['amount'] ?? 0),
                'status' => $p['status'] ?? 'pending',
                'created_date' => $p['created_date'] ?? date('c'),
                'paid_date' => $p['paid_date'] ?? null
            ];
        }, $payouts);
        
        echo json_encode([
            'grossSales' => $grossSales,
            'salesCount' => $salesCount,
            'totalCommissions' => $totalCommissions,
            'baseCosts' => $baseCosts,
            'totalProfit' => $totalProfit,
            'averageTicket' => $averageTicket,
            'artistCommissions' => array_values($artistMap),
            'payoutRequests' => array_values($payoutList),
            'monthlyHistory' => [
                ['label' => 'Jul/26', 'sales' => $grossSales * 0.2, 'commissions' => $totalCommissions * 0.2, 'profit' => $totalProfit * 0.2],
                ['label' => 'Ago/26', 'sales' => $grossSales * 0.3, 'commissions' => $totalCommissions * 0.3, 'profit' => $totalProfit * 0.3],
                ['label' => 'Set/26', 'sales' => $grossSales * 0.4, 'commissions' => $totalCommissions * 0.4, 'profit' => $totalProfit * 0.4],
                ['label' => 'Out/26', 'sales' => $grossSales, 'commissions' => $totalCommissions, 'profit' => $totalProfit]
            ]
        ]);
        exit;
    } else {
        $currentUser = !empty($store['currentUser']) ? $store['currentUser'] : [];
        $artistId = $currentUser['id'] ?? '69431e0c00397efc6e14e9e0';
        $artistName = $currentUser['name'] ?? 'Felipe Silvério';
        
        $artistGrossSales = 0;
        $artistTotalComm = 0;
        $artistSalesCount = 0;
        $processing = 0;
        
        foreach ($paidOrders as $order) {
            foreach (($order['items'] ?? []) as $item) {
                if (($item['artist_id'] ?? '') === $artistId || strcasecmp($item['artist_name'] ?? '', $artistName) === 0) {
                    $itemTotal = floatval($item['price'] ?? 0) * intval($item['quantity'] ?? 1);
                    $artistGrossSales += $itemTotal;
                    $artistSalesCount += intval($item['quantity'] ?? 1);
                    $rate = floatval($item['commission_rate'] ?? 25);
                    $artistTotalComm += ($itemTotal * $rate) / 100;
                }
            }
        }
        
        foreach ($pendingOrders as $order) {
            foreach (($order['items'] ?? []) as $item) {
                if (($item['artist_id'] ?? '') === $artistId || strcasecmp($item['artist_name'] ?? '', $artistName) === 0) {
                    $itemTotal = floatval($item['price'] ?? 0) * intval($item['quantity'] ?? 1);
                    $rate = floatval($item['commission_rate'] ?? 25);
                    $processing += ($itemTotal * $rate) / 100;
                }
            }
        }
        
        $artistPayouts = array_values(array_filter($payouts, function($p) use ($artistId) {
            return ($p['artist_id'] ?? '') === $artistId;
        }));
        
        $totalPaidOut = 0;
        $totalPendingPayout = 0;
        foreach ($artistPayouts as $p) {
            if (($p['status'] ?? '') === 'paid') $totalPaidOut += floatval($p['amount'] ?? 0);
            if (($p['status'] ?? '') === 'pending') $totalPendingPayout += floatval($p['amount'] ?? 0);
        }
        
        $available = max(0, $artistTotalComm - $totalPaidOut - $totalPendingPayout);
        
        echo json_encode([
            'available' => $available,
            'processing' => $processing,
            'totalCommissions' => $artistTotalComm,
            'salesCount' => $artistSalesCount,
            'grossSales' => $artistGrossSales,
            'viewsCount' => $artistSalesCount * 14 + 18,
            'pixKey' => $currentUser['pix_key'] ?? '',
            'pendingTransactions' => [],
            'payoutRequests' => $artistPayouts
        ]);
        exit;
    }
}

if ($route === '/functions/requestArtistPayout' && $method === 'POST') {
    $dataFile = __DIR__ . '/../../data/entities.json';
    if (!file_exists($dataFile)) $dataFile = __DIR__ . '/../data/entities.json';
    if (!file_exists($dataFile)) $dataFile = __DIR__ . '/data/entities.json';
    
    $store = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];
    $currentUser = !empty($store['currentUser']) ? $store['currentUser'] : [];
    
    if (empty($currentUser['pix_key'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Cadastre sua Chave Pix no perfil para receber repasses da Atma.']);
        exit;
    }
    
    $body = getJsonBody();
    $amount = floatval($body['amount'] ?? 10);
    $payout = [
        'id' => 'payout_' . time() . '_' . substr(md5(uniqid()), 0, 5),
        'artist_id' => $currentUser['id'] ?? '',
        'artist_name' => $currentUser['name'] ?? 'Artista',
        'artist_email' => $currentUser['email'] ?? '',
        'pix_key' => $currentUser['pix_key'],
        'amount' => $amount,
        'status' => 'pending',
        'created_date' => date('c')
    ];
    
    if (!isset($store['data']['PayoutRequest'])) $store['data']['PayoutRequest'] = [];
    array_unshift($store['data']['PayoutRequest'], $payout);
    @file_put_contents($dataFile, json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    echo json_encode(['success' => true, 'amount' => $amount, 'payout' => $payout]);
    exit;
}

if ($route === '/functions/confirmArtistPayout' && $method === 'POST') {
    $dataFile = __DIR__ . '/../../data/entities.json';
    if (!file_exists($dataFile)) $dataFile = __DIR__ . '/../data/entities.json';
    if (!file_exists($dataFile)) $dataFile = __DIR__ . '/data/entities.json';
    
    $store = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];
    $body = getJsonBody();
    $payoutId = $body['payoutId'] ?? '';
    
    if (!empty($store['data']['PayoutRequest'])) {
        foreach ($store['data']['PayoutRequest'] as &$p) {
            if (($p['id'] ?? '') === $payoutId) {
                $p['status'] = 'paid';
                $p['paid_date'] = date('c');
                break;
            }
        }
        unset($p);
        @file_put_contents($dataFile, json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    
    echo json_encode(['success' => true]);
    exit;
}

// Rota não encontrada
http_response_code(404);
echo json_encode([
    'error' => 'Endpoint não encontrado',
    'route' => $route
]);
