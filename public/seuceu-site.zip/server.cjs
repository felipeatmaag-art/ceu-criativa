var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_fs2 = __toESM(require("fs"), 1);
var import_genai = require("@google/genai");

// server/entitiesStore.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var DATA_DIR = import_path.default.join(process.cwd(), "data");
var DB_FILE = import_path.default.join(DATA_DIR, "entities.json");
var baseImage = "https://media.base44.com/images/public/69431e0c00397efc6e14e9df";
var APPAREL_VARIANTS = [
  { name: "BRANCA", hex: "#ffffff", front_url: "/mockups/tshirt-white-front.png", back_url: "/mockups/tshirt-white-back.jpg" },
  { name: "PRETA", hex: "#000000", front_url: "/mockups/tshirt-black-front.png", back_url: "/mockups/tshirt-black-back.jpg" },
  { name: "AZUL MARINHO", hex: "#1e3a8a", front_url: "/mockups/tshirt-navy-front.png", back_url: "/mockups/tshirt-navy-back.jpg" },
  { name: "CINZA", hex: "#6b7280", front_url: "/mockups/tshirt-gray-front.png", back_url: "/mockups/tshirt-gray-back.jpg" }
];
var DEFAULT_PRODUCTS = [
  {
    id: "fallback-camiseta",
    name: "Camiseta Essencial",
    type: "camiseta",
    catalog_product: true,
    is_active: true,
    base_price: 59.9,
    sizes_available: ["P", "M", "G", "GG"],
    colors_available: ["BRANCA", "PRETA", "AZUL MARINHO", "CINZA"],
    front_model_url: "/mockups/tshirt-white-front.png",
    back_model_url: "/mockups/tshirt-white-back.jpg",
    product_color_variants: APPAREL_VARIANTS,
    created_date: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "fallback-baby-look",
    name: "Baby Look Essencial",
    type: "baby_look",
    catalog_product: true,
    is_active: true,
    base_price: 49.9,
    sizes_available: ["P", "M", "G", "GG"],
    colors_available: ["BRANCA", "PRETA", "AZUL MARINHO", "CINZA"],
    front_model_url: "/mockups/tshirt-white-front.png",
    back_model_url: "/mockups/tshirt-white-back.jpg",
    product_color_variants: APPAREL_VARIANTS,
    created_date: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "fallback-caneca",
    name: "Caneca Aurora",
    type: "caneca",
    catalog_product: true,
    is_active: true,
    base_price: 39.9,
    sizes_available: ["325ml"],
    colors_available: ["BRANCA"],
    front_model_url: `${baseImage}/a376cd8cc_generated_image.png`,
    back_model_url: `${baseImage}/9373e007c_generated_image.png`,
    product_color_variants: [
      {
        name: "BRANCA",
        hex: "#ffffff",
        front_url: `${baseImage}/a376cd8cc_generated_image.png`,
        back_url: `${baseImage}/9373e007c_generated_image.png`
      }
    ],
    created_date: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "fallback-ecobag",
    name: "Ecobag Horizonte",
    type: "ecobag",
    catalog_product: true,
    is_active: true,
    base_price: 34.9,
    sizes_available: ["\xDAnico"],
    colors_available: ["PRETA"],
    front_model_url: `${baseImage}/373ae2537_generated_image.png`,
    back_model_url: `${baseImage}/020045638_generated_image.png`,
    product_color_variants: [
      {
        name: "PRETA",
        hex: "#000000",
        front_url: `${baseImage}/373ae2537_generated_image.png`,
        back_url: `${baseImage}/020045638_generated_image.png`
      }
    ],
    created_date: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "fallback-quadro",
    name: "Quadro Janela",
    type: "quadro",
    catalog_product: true,
    is_active: true,
    base_price: 89.9,
    sizes_available: ["A4", "A3"],
    colors_available: ["PRETO"],
    front_model_url: `${baseImage}/97e914a15_generated_image.png`,
    back_model_url: `${baseImage}/aa3ec4f0d_generated_image.png`,
    product_color_variants: [
      {
        name: "PRETO",
        hex: "#000000",
        front_url: `${baseImage}/97e914a15_generated_image.png`,
        back_url: `${baseImage}/aa3ec4f0d_generated_image.png`
      }
    ],
    created_date: (/* @__PURE__ */ new Date()).toISOString()
  }
];
var photos = [
  "1550859492-d5da9d8e45f3",
  "1511497584788-876760111969",
  "1487958449943-2429e8be8625",
  "1549490349-8643362247b5",
  "1577083552431-6e5fd01aa342",
  "1517841905240-472988babdf9",
  "1557682250-33bd709cbe85",
  "1500530855697-b586d89ba3ee",
  "1550745165-9bc0b252726f",
  "1541701494587-cb58502866ab"
];
var titles = [
  "Sol de Dentro",
  "Mata Atl\xE2ntica",
  "Concreto Vivo",
  "Linha Serena",
  "Bicho do C\xE9u",
  "Vai Dar C\xE9u",
  "\xD3rbita Tropical",
  "Postal 1987",
  "Mar\xE9 Criativa",
  "Noite Brasileira"
];
var categories = [
  "abstrato",
  "natureza",
  "urbano",
  "minimalista",
  "ilustracao",
  "tipografia",
  "geometrico",
  "vintage",
  "pop_art",
  "surreal"
];
var DEFAULT_DESIGNS = titles.map((title, index) => ({
  id: `fallback-design-${index + 1}`,
  title,
  artist_name: "C\xE9u Criativa",
  artist_id: "artist_user_1",
  description: "Estampa de demonstra\xE7\xE3o do cat\xE1logo.",
  image_url: `https://images.unsplash.com/photo-${photos[index]}?auto=format&fit=crop&w=1200&q=85`,
  price_base: 19.9,
  category: categories[index],
  tags: ["arte", "c\xE9u"],
  status: "aprovado",
  is_featured: true,
  likes_count: 12 + index * 3,
  sales_count: index * 4,
  created_date: new Date(Date.now() - index * 864e5).toISOString()
}));
var DEFAULT_CATEGORIES = categories.map((cat, idx) => ({
  id: `cat-${idx + 1}`,
  name: cat.charAt(0).toUpperCase() + cat.slice(1).replace("_", " "),
  slug: cat,
  position_order: idx
}));
var DEFAULT_COLLECTIONS = [
  {
    id: "col-1",
    name: "Destaques do C\xE9u",
    slug: "destaques-do-ceu",
    description: "Estampas mais procuradas pelos criadores.",
    is_public: true,
    is_active: true,
    position_order: 1
  },
  {
    id: "col-2",
    name: "Natureza Brasileira",
    slug: "natureza-brasileira",
    description: "Biomas, fauna e flora em tra\xE7os contempor\xE2neos.",
    is_public: true,
    is_active: true,
    position_order: 2
  }
];
var DEFAULT_COMPETITION = [
  {
    id: "comp-1",
    title: "Cores do Ver\xE3o",
    theme: "Ver\xE3o Tropical & Movimento",
    description: "Concurso aberto para artistas criarem a melhor estampa tem\xE1tica de ver\xE3o.",
    banner_url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
    status: "active",
    start_date: new Date(Date.now() - 7 * 864e5).toISOString(),
    end_date: new Date(Date.now() + 30 * 864e5).toISOString(),
    prize_description: "R$ 2.500 em dinheiro + produ\xE7\xE3o e destaque nacional",
    submissions_count: 8,
    created_date: (/* @__PURE__ */ new Date()).toISOString()
  }
];
var DEFAULT_USER = {
  id: "artist_user_1",
  name: "Felipe Silv\xE9rio",
  full_name: "Felipe Silv\xE9rio",
  artist_name: "Felipe Silv\xE9rio",
  email: "felipeatmaag@gmail.com",
  cpf: "",
  pix_key: "",
  phone: "",
  role: "admin",
  app_role: "master",
  store_slug: "ceu-criativa",
  store_name: "C\xE9u Criativa Studio",
  bio: "Est\xFAdio de design e ilustra\xE7\xF5es autorais no C\xE9u Criativa.",
  avatar_url: "",
  has_completed_profile: false,
  has_purchased_first_print: false,
  store_active: false,
  total_sales: 0,
  rating: 5,
  access_status: "active",
  created_date: "2025-01-01T00:00:00.000Z"
};
var DEFAULT_COMMISSION = [
  {
    id: "comm_1",
    artist_id: "artist_user_1",
    rate_percentage: 20,
    pending_balance: 340.5,
    paid_balance: 1820,
    updated_date: (/* @__PURE__ */ new Date()).toISOString()
  }
];
var EntitiesStore = class {
  data = {};
  currentUser = { ...DEFAULT_USER };
  constructor() {
    this.init();
  }
  init() {
    if (!import_fs.default.existsSync(DATA_DIR)) {
      try {
        import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
      } catch {
      }
    }
    if (import_fs.default.existsSync(DB_FILE)) {
      try {
        const raw = import_fs.default.readFileSync(DB_FILE, "utf-8");
        const parsed = JSON.parse(raw);
        this.data = parsed.data || {};
        if (parsed.currentUser) {
          this.currentUser = {
            ...this.currentUser,
            ...parsed.currentUser,
            name: parsed.currentUser.name || parsed.currentUser.full_name || "Artista Criativo"
          };
        }
        const matchedUser = this.data.User?.find(
          (u) => u.email === "felipeatmaag@gmail.com" || u.id === "69431e0c00397efc6e14e9e0"
        );
        if (matchedUser) {
          this.currentUser = {
            ...this.currentUser,
            ...matchedUser,
            name: matchedUser.name || matchedUser.full_name || matchedUser.artist_name || "Felipe Silv\xE9rio"
          };
        }
        const hasExistingOrder = this.data.Order?.some(
          (o) => o.customer_email === this.currentUser.email || o.artist_id === this.currentUser.id
        );
        if (hasExistingOrder) {
          this.currentUser.has_purchased_first_print = true;
          this.currentUser.store_active = true;
        }
      } catch {
        this.seedDefaults();
      }
    } else {
      this.seedDefaults();
    }
    if (!this.data.Product || this.data.Product.length === 0) {
      this.data.Product = [...DEFAULT_PRODUCTS];
    }
    if (!this.data.Design || this.data.Design.length === 0) {
      this.data.Design = [...DEFAULT_DESIGNS];
    }
    if (!this.data.Category || this.data.Category.length === 0) {
      this.data.Category = [...DEFAULT_CATEGORIES];
    }
    if (!this.data.Collection || this.data.Collection.length === 0) {
      this.data.Collection = [...DEFAULT_COLLECTIONS];
    }
    if (!this.data.Competition || this.data.Competition.length === 0) {
      this.data.Competition = [...DEFAULT_COMPETITION];
    }
    if (!this.data.ArtistCommission || this.data.ArtistCommission.length === 0) {
      this.data.ArtistCommission = [...DEFAULT_COMMISSION];
    }
    if (!this.data.User || this.data.User.length === 0) {
      this.data.User = [{ ...this.currentUser }];
    }
    this.persist();
  }
  seedDefaults() {
    this.data = {
      Product: [...DEFAULT_PRODUCTS],
      Design: [...DEFAULT_DESIGNS],
      Category: [...DEFAULT_CATEGORIES],
      Collection: [...DEFAULT_COLLECTIONS],
      Competition: [...DEFAULT_COMPETITION],
      ArtistCommission: [...DEFAULT_COMMISSION],
      User: [{ ...this.currentUser }],
      Like: [],
      Comment: [],
      Follow: [],
      Order: [],
      LoyaltyPoint: [],
      Reward: [],
      RewardRedemption: [],
      BaseProductVariant: [],
      DesignView: []
    };
  }
  persist() {
    try {
      if (!import_fs.default.existsSync(DATA_DIR)) {
        import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
      }
      import_fs.default.writeFileSync(
        DB_FILE,
        JSON.stringify(
          {
            data: this.data,
            currentUser: this.currentUser
          },
          null,
          2
        ),
        "utf-8"
      );
    } catch (e) {
      console.error("[EntitiesStore] Failed to persist:", e);
    }
  }
  getCollection(name) {
    if (!this.data[name]) {
      this.data[name] = [];
    }
    return this.data[name];
  }
  list(name, options = {}) {
    const coll = this.getCollection(name);
    let results = [...coll];
    if (options.q && typeof options.q === "object") {
      results = results.filter((item) => {
        for (const [key, val] of Object.entries(options.q)) {
          if (val === void 0) continue;
          if (key === "artist_id") {
            const matchesArtist = item.artist_id === val || item.created_by_id === val || typeof val === "string" && (item.created_by?.toLowerCase() === val.toLowerCase() || item.artist_name?.toLowerCase() === val.toLowerCase());
            if (!matchesArtist) return false;
            continue;
          }
          if (item[key] === val) continue;
          if (val === true && (item[key] === true || item[key] === "true")) continue;
          if (val === false && (item[key] === false || item[key] === "false")) continue;
          if (val === "true" && (item[key] === true || item[key] === "true")) continue;
          if (val === "false" && (item[key] === false || item[key] === "false")) continue;
          if (String(item[key]) === String(val)) continue;
          return false;
        }
        return true;
      });
    }
    if (options.sort) {
      const isDesc = options.sort.startsWith("-");
      const field = isDesc ? options.sort.slice(1) : options.sort;
      results.sort((a, b) => {
        const valA = a[field];
        const valB = b[field];
        if (valA === valB) return 0;
        if (valA === void 0 || valA === null) return 1;
        if (valB === void 0 || valB === null) return -1;
        if (typeof valA === "number" && typeof valB === "number") {
          return isDesc ? valB - valA : valA - valB;
        }
        if (valA < valB) return isDesc ? 1 : -1;
        return isDesc ? -1 : 1;
      });
    }
    const skip = options.skip || 0;
    const limit = options.limit !== void 0 ? options.limit : name === "Design" || name === "Product" || name === "User" ? 250 : 100;
    return results.slice(skip, skip + limit);
  }
  get(name, id) {
    const coll = this.getCollection(name);
    return coll.find((item) => String(item.id) === String(id)) || null;
  }
  create(name, data) {
    const coll = this.getCollection(name);
    const id = data.id || `ent_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const created = {
      ...data,
      id,
      created_date: data.created_date || (/* @__PURE__ */ new Date()).toISOString(),
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    };
    coll.unshift(created);
    this.persist();
    return created;
  }
  update(name, id, data) {
    const coll = this.getCollection(name);
    const index = coll.findIndex((item) => String(item.id) === String(id));
    if (index === -1) {
      return this.create(name, { ...data, id });
    }
    const updated = {
      ...coll[index],
      ...data,
      id,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    };
    coll[index] = updated;
    this.persist();
    return updated;
  }
  delete(name, id) {
    const coll = this.getCollection(name);
    const index = coll.findIndex((item) => String(item.id) === String(id));
    if (index !== -1) {
      coll.splice(index, 1);
      this.persist();
      return true;
    }
    return false;
  }
  deleteMany(name, query) {
    if (!query) return 0;
    let coll = this.getCollection(name);
    const initialLen = coll.length;
    let idSet = null;
    if (Array.isArray(query)) {
      idSet = new Set(query.map(String));
    } else if (Array.isArray(query.ids)) {
      idSet = new Set(query.ids.map(String));
    }
    if (idSet) {
      this.data[name] = coll.filter((item) => !idSet.has(String(item.id)));
    } else if (typeof query === "object") {
      this.data[name] = coll.filter((item) => {
        for (const [k, v] of Object.entries(query)) {
          if (item[k] === v) return false;
        }
        return true;
      });
    }
    this.persist();
    return initialLen - this.data[name].length;
  }
  updateMe(data) {
    this.currentUser = {
      ...this.currentUser,
      ...data,
      updated_date: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.update("User", this.currentUser.id, this.currentUser);
    this.persist();
    return this.currentUser;
  }
};
var entitiesStore = new EntitiesStore();

// server.ts
var import_multer = __toESM(require("multer"), 1);

// src/server/cieloService.ts
var import_crypto = __toESM(require("crypto"), 1);
function detectCardBrand(number) {
  const clean = (number || "").replace(/\D/g, "");
  if (/^4/.test(clean)) return "Visa";
  if (/^(5[1-5]|2[2-7])/.test(clean)) return "Master";
  if (/^3[47]/.test(clean)) return "Amex";
  if (/^(4011|4312|4389|4514|4576|5041|5066|5090|6277|6362|6363|650|6516|6550)/.test(clean)) return "Elo";
  if (/^(606282|3841)/.test(clean)) return "Hipercard";
  return "Visa";
}
function formatExpirationDate(exp) {
  const clean = (exp || "").replace(/\D/g, "");
  if (clean.length === 4) {
    const mm = clean.slice(0, 2);
    const yy = clean.slice(2, 4);
    return `${mm}/20${yy}`;
  }
  if (clean.length === 6) {
    return `${clean.slice(0, 2)}/${clean.slice(2, 6)}`;
  }
  return exp;
}
async function processCieloPayment(payload, orderNumber) {
  const merchantId = process.env.CIELO_MERCHANT_ID;
  const merchantKey = process.env.CIELO_MERCHANT_KEY;
  const isProduction = process.env.CIELO_ENVIRONMENT === "production";
  const baseUrl = isProduction ? "https://api.cieloecommerce.cielo.com.br/1/sales/" : "https://apisandbox.cieloecommerce.cielo.com.br/1/sales/";
  const amountInCents = Math.round(payload.totalAmount * 100);
  const cleanCpf = (payload.customer.cpf || "").replace(/\D/g, "") || "11111111111";
  const cleanZip = (payload.shippingAddress.zipcode || "").replace(/\D/g, "") || "01310100";
  if (merchantId && merchantKey) {
    try {
      let cieloBody = {
        MerchantOrderId: orderNumber,
        Customer: {
          Name: payload.customer.name,
          Email: payload.customer.email,
          Identity: cleanCpf,
          IdentityType: "CPF",
          DeliveryAddress: {
            Street: payload.shippingAddress.street,
            Number: payload.shippingAddress.number || "SN",
            Complement: payload.shippingAddress.complement || "",
            ZipCode: cleanZip,
            City: payload.shippingAddress.city,
            State: payload.shippingAddress.state,
            Country: "BRA"
          }
        }
      };
      if (payload.paymentMethod === "credit_card" && payload.card) {
        const brand = payload.card.brand || detectCardBrand(payload.card.cardNumber);
        cieloBody.Payment = {
          Type: "CreditCard",
          Amount: amountInCents,
          Installments: Number(payload.installments) || 1,
          SoftDescriptor: "CEU CRIATIVA",
          Capture: true,
          CreditCard: {
            CardNumber: payload.card.cardNumber.replace(/\D/g, ""),
            Holder: payload.card.holder.trim().toUpperCase(),
            ExpirationDate: formatExpirationDate(payload.card.expirationDate),
            SecurityCode: payload.card.securityCode.trim(),
            Brand: brand
          }
        };
      } else if (payload.paymentMethod === "pix") {
        cieloBody.Payment = {
          Type: "Pix",
          Amount: amountInCents
        };
      } else if (payload.paymentMethod === "boleto") {
        cieloBody.Payment = {
          Type: "Boleto",
          Amount: amountInCents,
          Provider: "Bradesco2",
          Instructions: "N\xE3o receber ap\xF3s o vencimento"
        };
      }
      const cieloResponse = await fetch(baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "MerchantId": merchantId,
          "MerchantKey": merchantKey,
          "RequestId": import_crypto.default.randomUUID()
        },
        body: JSON.stringify(cieloBody)
      });
      const data = await cieloResponse.json();
      if (!cieloResponse.ok) {
        const errMsg = Array.isArray(data) ? data.map((d) => d.Message).join(", ") : data.Message || "Erro ao comunicar com a Cielo.";
        throw new Error(errMsg);
      }
      const payment = data.Payment || {};
      const status = payment.Status;
      const isApproved = status === 1 || status === 2;
      return {
        success: isApproved || status === 12,
        isApproved,
        status: isApproved ? "paid" : status === 12 ? "pending" : "denied",
        paymentId: payment.PaymentId,
        tid: payment.Tid,
        authCode: payment.AuthorizationCode,
        proofOfSale: payment.ProofOfSale,
        returnCode: payment.ReturnCode,
        returnMessage: payment.ReturnMessage || (isApproved ? "Transa\xE7\xE3o autorizada com sucesso" : "Pagamento pendente"),
        qrCodeBase64: payment.QrCodeBase64Image,
        qrCodeString: payment.QrCodeString,
        boletoBarCode: payment.BarCodeNumber,
        boletoUrl: payment.Url,
        raw: data
      };
    } catch (err) {
      console.warn("Falha na requisi\xE7\xE3o direta da Cielo:", err.message);
    }
  }
  const paymentId = import_crypto.default.randomUUID();
  const tid = "10" + Date.now().toString().slice(-8) + Math.floor(1e3 + Math.random() * 9e3);
  const authCode = Math.floor(1e5 + Math.random() * 9e5).toString();
  const nsu = Math.floor(1e8 + Math.random() * 9e8).toString();
  if (payload.paymentMethod === "credit_card") {
    const cardClean = payload.card?.cardNumber?.replace(/\D/g, "") || "";
    const isDeclinedTest = cardClean.endsWith("0000");
    if (isDeclinedTest) {
      return {
        success: false,
        isApproved: false,
        status: "denied",
        paymentId,
        returnCode: "05",
        returnMessage: "N\xE3o autorizada. Verifique os dados do cart\xE3o ou limite dispon\xEDvel."
      };
    }
    return {
      success: true,
      isApproved: true,
      status: "paid",
      paymentId,
      tid,
      authCode,
      proofOfSale: nsu,
      returnCode: "00",
      returnMessage: "Transa\xE7\xE3o autorizada com sucesso pela Cielo",
      cardBrand: payload.card?.brand || detectCardBrand(payload.card?.cardNumber || ""),
      cardLast4: cardClean.slice(-4) || "1234"
    };
  }
  if (payload.paymentMethod === "pix") {
    const pixKey = "cielo-pix-" + orderNumber.toLowerCase();
    const qrCodeString = `00020126580014BR.GOV.BCB.PIX0136${pixKey}5204000053039865406${payload.totalAmount.toFixed(2)}5802BR5912CEU CRIATIVA6009SAO PAULO62070503***6304`;
    const qrSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200"><rect width="200" height="200" fill="#ffffff"/><path d="M20 20h50v50h-50zM30 30h30v30h-30zM130 20h50v50h-50zM140 30h30v30h-30zM20 130h50v50h-50zM30 140h30v30h-30zM80 30h20v20h-20zM90 60h20v20h-20zM30 90h20v20h-20zM80 90h40v40h-40zM140 90h20v20h-20zM90 140h20v20h-20zM130 130h20v20h-20zM160 140h20v40h-20zM130 170h20v10h-20z" fill="#002D72"/></svg>`;
    const qrCodeBase64 = "data:image/svg+xml;base64," + Buffer.from(qrSvg).toString("base64");
    return {
      success: true,
      isApproved: false,
      status: "pending",
      paymentId,
      tid,
      qrCodeString,
      qrCodeBase64,
      returnCode: "12",
      returnMessage: "Pix Cielo gerado com sucesso. Aguardando pagamento."
    };
  }
  const boletoBarCode = "23793.38128 60000.000004 01000.644208 1 " + Math.floor(1e13 + Math.random() * 9e13);
  return {
    success: true,
    isApproved: false,
    status: "pending",
    paymentId,
    tid,
    boletoBarCode,
    boletoUrl: `https://cielo.com.br/boleto/${paymentId}`,
    returnCode: "12",
    returnMessage: "Boleto banc\xE1rio gerado com sucesso."
  };
}

// server.ts
var sharp = null;
try {
  sharp = require("sharp");
} catch (_e) {
  console.warn("Aviso: M\xF3dulo 'sharp' n\xE3o encontrado ou incompat\xEDvel com este SO. Fun\xE7\xF5es de recorte avan\xE7ado de estampa rodar\xE3o em modo direto.");
}
var PORT = Number(process.env.PORT) || 3e3;
var UPLOADS_DIR = import_path2.default.join(process.cwd(), "public", "uploads");
if (!import_fs2.default.existsSync(UPLOADS_DIR)) {
  import_fs2.default.mkdirSync(UPLOADS_DIR, { recursive: true });
}
var genAIClient = null;
function getGenAIClient() {
  if (!genAIClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY n\xE3o foi configurada no ambiente.");
    }
    genAIClient = new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return genAIClient;
}
async function generateWithFallback(ai, models, contents, config, timeoutMs = 25e3) {
  let lastError = null;
  for (const model of models) {
    try {
      const generatePromise = ai.models.generateContent({
        model,
        contents,
        config: config && Object.keys(config).length > 0 ? config : void 0
      });
      const timeoutPromise = new Promise(
        (_, reject) => setTimeout(() => reject(new Error(`Timeout na chamada do modelo ${model}`)), timeoutMs)
      );
      const res = await Promise.race([generatePromise, timeoutPromise]);
      return res;
    } catch (err) {
      lastError = err;
      console.warn(`Modelo ${model} falhou (${err?.message}), tentando fallback...`);
    }
  }
  throw lastError;
}
async function resolveImagePart(imageUrl) {
  if (!imageUrl) return null;
  if (imageUrl.startsWith("data:")) {
    const matches = imageUrl.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
    if (matches) {
      return {
        mimeType: matches[1],
        data: matches[2]
      };
    }
  }
  if (imageUrl.startsWith("/uploads/")) {
    try {
      const cleanName = import_path2.default.basename(imageUrl.split("?")[0]);
      const filePath = import_path2.default.join(UPLOADS_DIR, cleanName);
      if (import_fs2.default.existsSync(filePath)) {
        const fileBuffer = await import_fs2.default.promises.readFile(filePath);
        const ext = import_path2.default.extname(cleanName).toLowerCase();
        const mimeType = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".webp" ? "image/webp" : "image/png";
        return {
          mimeType,
          data: fileBuffer.toString("base64")
        };
      }
    } catch (err) {
      console.error("Erro ao ler upload local:", err);
    }
  }
  try {
    const urlToFetch = imageUrl.startsWith("http://") || imageUrl.startsWith("https://") ? imageUrl : `http://127.0.0.1:${PORT}${imageUrl.startsWith("/") ? "" : "/"}${imageUrl}`;
    const res = await fetch(urlToFetch);
    if (!res.ok) return null;
    const contentType = res.headers.get("content-type") || "image/png";
    const arrayBuffer = await res.arrayBuffer();
    const base64 = Buffer.from(arrayBuffer).toString("base64");
    return {
      mimeType: contentType.split(";")[0],
      data: base64
    };
  } catch (err) {
    console.error("Erro ao converter imagem de refer\xEAncia:", err);
    return null;
  }
}
async function startServer() {
  const app = (0, import_express.default)();
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });
  app.use(import_express.default.json({ limit: "50mb" }));
  app.use(import_express.default.urlencoded({ extended: true, limit: "50mb" }));
  const MOCKUPS_DIR = import_path2.default.join(process.cwd(), "public", "mockups");
  const distMockups = import_path2.default.join(process.cwd(), "dist", "mockups");
  const distUploads = import_path2.default.join(process.cwd(), "dist", "uploads");
  if (import_fs2.default.existsSync(distMockups)) {
    app.use(["/mockups", "/api/mockups"], import_express.default.static(distMockups, {
      setHeaders: (res) => {
        res.setHeader("Access-Control-Allow-Origin", "*");
      }
    }));
  }
  app.use(["/mockups", "/api/mockups"], import_express.default.static(MOCKUPS_DIR, {
    setHeaders: (res) => {
      res.setHeader("Access-Control-Allow-Origin", "*");
    }
  }));
  if (import_fs2.default.existsSync(distUploads)) {
    app.use(["/uploads", "/api/uploads"], import_express.default.static(distUploads, {
      setHeaders: (res) => {
        res.setHeader("Access-Control-Allow-Origin", "*");
      }
    }));
  }
  app.use(["/uploads", "/api/uploads"], import_express.default.static(UPLOADS_DIR, {
    setHeaders: (res) => {
      res.setHeader("Access-Control-Allow-Origin", "*");
    }
  }));
  const multerStorage = import_multer.default.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
    filename: (_req, file, cb) => {
      const cleanFilename = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
      cb(null, `${Date.now()}-${cleanFilename}`);
    }
  });
  const uploadMiddleware = (0, import_multer.default)({
    storage: multerStorage,
    limits: { fileSize: 50 * 1024 * 1024 }
  });
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", service: "ceu-criativa-gemini" });
  });
  const uploadRoutes = [
    "/api/upload",
    "/api/apps/:appId/integration-endpoints/Core/UploadFile",
    "/api/apps/:appId/integration-endpoints/Core/UploadPrivateFile",
    "/apps/:appId/integration-endpoints/Core/UploadFile",
    "/apps/:appId/integration-endpoints/Core/UploadPrivateFile",
    "/integration-endpoints/Core/UploadFile",
    "/integration-endpoints/Core/UploadPrivateFile"
  ];
  app.post(uploadRoutes, uploadMiddleware.single("file"), async (req, res) => {
    try {
      if (req.file) {
        const fileUrl2 = `/uploads/${req.file.filename}`;
        return res.json({
          file_url: fileUrl2,
          url: fileUrl2,
          file_uri: fileUrl2,
          filename: req.file.originalname,
          size: req.file.size,
          mime_type: req.file.mimetype
        });
      }
      const { data, filename, mimeType } = req.body || {};
      if (!data) {
        return res.status(400).json({ error: "Nenhum dado enviado." });
      }
      const cleanFilename = (filename || `upload-${Date.now()}.png`).replace(/[^a-zA-Z0-9._-]/g, "_");
      const safeFilename = `${Date.now()}-${cleanFilename}`;
      const filePath = import_path2.default.join(UPLOADS_DIR, safeFilename);
      let buffer;
      if (typeof data === "string" && data.startsWith("data:")) {
        const base64Data = data.replace(/^data:[^;]+;base64,/, "");
        buffer = Buffer.from(base64Data, "base64");
      } else if (typeof data === "string") {
        buffer = Buffer.from(data, "base64");
      } else {
        return res.status(400).json({ error: "Formato de arquivo inv\xE1lido." });
      }
      await import_fs2.default.promises.writeFile(filePath, buffer);
      const fileUrl = `/uploads/${safeFilename}`;
      res.json({
        file_url: fileUrl,
        url: fileUrl,
        file_uri: fileUrl,
        filename: safeFilename,
        size: buffer.length,
        mime_type: mimeType || "image/png"
      });
    } catch (err) {
      console.error("Erro no upload:", err);
      res.status(500).json({ error: err.message || "Falha no upload do arquivo." });
    }
  });
  const signedUrlRoutes = [
    "/api/apps/:appId/integration-endpoints/Core/CreateFileSignedUrl",
    "/apps/:appId/integration-endpoints/Core/CreateFileSignedUrl",
    "/integration-endpoints/Core/CreateFileSignedUrl"
  ];
  app.post(signedUrlRoutes, (req, res) => {
    const fileUri = req.body?.file_uri || req.body?.file_url || "";
    res.json({ signed_url: fileUri });
  });
  const imageRoutes = [
    "/api/gemini/generate-image",
    "/api/apps/:appId/integration-endpoints/Core/GenerateImage",
    "/apps/:appId/integration-endpoints/Core/GenerateImage",
    "/integration-endpoints/Core/GenerateImage"
  ];
  function sanitizePrintPrompt(rawPrompt) {
    if (!rawPrompt) return "";
    let clean = rawPrompt;
    clean = clean.replace(/\b(camiseta|camisa|blusa|baby\s*look|moletom|t-?shirt|regata|polo|jaqueta|vestu[aá]rio)\s+preta\s+(de|com|do|da)?\b/gi, "arte gr\xE1fica vetorial em alto contraste com ");
    clean = clean.replace(/\b(camiseta|camisa|blusa|baby\s*look|moletom|t-?shirt|regata|polo|jaqueta|vestu[aá]rio)\s+branca\s+(de|com|do|da)?\b/gi, "arte gr\xE1fica vetorial com ");
    clean = clean.replace(/\b(camiseta|camisa|blusa|baby\s*look|moletom|t-?shirt|regata|polo|jaqueta|vestu[aá]rio)\s+(de|com|do|da)?\b/gi, "ilustra\xE7\xE3o vetorial de ");
    clean = clean.replace(/\b(estampa|desenho|arte)\s+(para|de|em|pra)\s+(camiseta|camisa|blusa|roupa|moletom|t-?shirt)\b/gi, "ilustra\xE7\xE3o gr\xE1fica vetorial isolada");
    clean = clean.replace(/\b(em\s+uma|numa|na|no)\s+(camiseta|camisa|blusa|roupa|moletom|t-?shirt)\b/gi, "em formato decalque adesivo");
    clean = clean.replace(/\b(mockup|gola|manga|mangas|tecido|cabide|manequim|pessoa vestindo)\b/gi, "");
    clean = clean.replace(/\b(camisetas|camiseta|camisas|camisa|t-?shirts?|roupas|roupa|moletom)\b/gi, "arte gr\xE1fica");
    clean = clean.replace(/\s+/g, " ").trim();
    return clean;
  }
  async function detectGarmentInImage(ai, imageBuffer) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: [
          {
            parts: [
              { text: `Analyze this image created for a print platform. Determine if the image displays a garment/clothing/t-shirt mockup (such as a shirt body, collar, sleeves, fabric) instead of being ONLY an isolated graphic illustration sticker on green background.
If it has a garment, find the bounding box of ONLY the graphic illustration / print on the chest of that garment.
Return strictly JSON:
{
  "has_garment": boolean,
  "explanation": "brief reason",
  "print_bbox_normalized_1000": [ymin, xmin, ymax, xmax] | null
}` },
              { inlineData: { mimeType: "image/jpeg", data: imageBuffer.toString("base64") } }
            ]
          }
        ],
        config: {
          responseMimeType: "application/json"
        }
      });
      const parsed = JSON.parse(response.text || "{}");
      return {
        has_garment: Boolean(parsed.has_garment),
        explanation: parsed.explanation || "",
        print_bbox_normalized_1000: Array.isArray(parsed.print_bbox_normalized_1000) && parsed.print_bbox_normalized_1000.length === 4 ? parsed.print_bbox_normalized_1000 : null
      };
    } catch (e) {
      console.warn("Falha na detec\xE7\xE3o de vestu\xE1rio na imagem:", e?.message);
      return { has_garment: false, print_bbox_normalized_1000: null };
    }
  }
  async function isolatePrintGraphicFromGarment(ai, imageBuffer, preDetectedBbox) {
    try {
      let bbox = preDetectedBbox;
      if (!bbox) {
        const detection = await detectGarmentInImage(ai, imageBuffer);
        bbox = detection.print_bbox_normalized_1000;
      }
      if (sharp && bbox && bbox.length === 4) {
        const meta = await sharp(imageBuffer).metadata();
        const width = meta.width || 1024;
        const height = meta.height || 1024;
        const ymin = Math.max(0, Math.round(bbox[0] / 1e3 * height));
        const xmin = Math.max(0, Math.round(bbox[1] / 1e3 * width));
        const ymax = Math.min(height, Math.round(bbox[2] / 1e3 * height));
        const xmax = Math.min(width, Math.round(bbox[3] / 1e3 * width));
        const cropWidth = Math.max(10, xmax - xmin);
        const cropHeight = Math.max(10, ymax - ymin);
        const croppedChest = await sharp(imageBuffer).extract({ left: xmin, top: ymin, width: cropWidth, height: cropHeight }).toBuffer();
        const padX = Math.round(cropWidth * 0.15);
        const padY = Math.round(cropHeight * 0.15);
        const canvasW = cropWidth + padX * 2;
        const canvasH = cropHeight + padY * 2;
        const compositeBuffer = await sharp({
          create: {
            width: canvasW,
            height: canvasH,
            channels: 4,
            background: { r: 0, g: 255, b: 0, alpha: 1 }
          }
        }).composite([
          {
            input: croppedChest,
            left: padX,
            top: padY
          }
        ]).png().toBuffer();
        return {
          buffer: compositeBuffer,
          mimeType: "image/png"
        };
      }
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-image",
        contents: [
          {
            parts: [
              { text: "Extract ONLY the graphic illustration artwork printed on the chest of this t-shirt/clothing. Render strictly the 2D flat graphic design artwork, isolated and centered on a pure solid green background #00FF00. Do not include any t-shirt, collar, sleeves, fabric, or clothing." },
              { inlineData: { mimeType: "image/jpeg", data: imageBuffer.toString("base64") } }
            ]
          }
        ],
        config: { imageConfig: { aspectRatio: "1:1" } }
      });
      const candidates = response.candidates;
      const parts = candidates?.[0]?.content?.parts || [];
      for (const part of parts) {
        if (part.inlineData) {
          return {
            buffer: Buffer.from(part.inlineData.data, "base64"),
            mimeType: part.inlineData.mimeType || "image/png"
          };
        }
      }
      return null;
    } catch (err) {
      console.error("Falha ao isolar estampa de pe\xE7a de vestu\xE1rio:", err);
      return null;
    }
  }
  app.post(["/api/gemini/isolate-print-art", "/api/gemini/crop-print-artwork"], async (req, res) => {
    try {
      const { image_url, data } = req.body || {};
      let buffer = null;
      if (data) {
        const base64Data = data.replace(/^data:[^;]+;base64,/, "");
        buffer = Buffer.from(base64Data, "base64");
      } else if (image_url) {
        const part = await resolveImagePart(image_url);
        if (part) {
          buffer = Buffer.from(part.data, "base64");
        }
      }
      if (!buffer) {
        return res.status(400).json({ error: "Imagem de entrada n\xE3o fornecida ou inv\xE1lida." });
      }
      const ai = getGenAIClient();
      const isolated = await isolatePrintGraphicFromGarment(ai, buffer);
      if (!isolated) {
        return res.status(500).json({ error: "N\xE3o foi poss\xEDvel isolar a arte gr\xE1fica da camiseta." });
      }
      const filename = `gemini-isolated-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.png`;
      const filePath = import_path2.default.join(UPLOADS_DIR, filename);
      await import_fs2.default.promises.writeFile(filePath, isolated.buffer);
      const url = `/uploads/${filename}`;
      res.json({
        url,
        file_url: url,
        mime_type: "image/png"
      });
    } catch (err) {
      console.error("Erro no isolate-print-art:", err);
      res.status(500).json({ error: err.message || "Erro ao isolar a estampa." });
    }
  });
  app.post(imageRoutes, async (req, res) => {
    try {
      const { prompt, existing_image_urls, aspectRatio, productColor, colorName, colorHex, productType } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "O prompt \xE9 obrigat\xF3rio." });
      }
      const ai = getGenAIClient();
      const parts = [];
      if (Array.isArray(existing_image_urls) && existing_image_urls.length > 0) {
        for (const imgUrl of existing_image_urls) {
          const imgPart = await resolveImagePart(imgUrl);
          if (imgPart) {
            parts.push({
              inlineData: {
                data: imgPart.data,
                mimeType: imgPart.mimeType
              }
            });
          }
        }
      }
      const sanitizedSubject = sanitizePrintPrompt(prompt);
      const isDark = colorName && /black|preto|preta|navy|marinho|dark|escuro|escura|wine|vinho|bordo|chumbo|militar|verde_escuro/i.test(colorName) || productColor && /black|preto|preta|navy|marinho|dark|escuro|escura|wine|vinho|bordo|chumbo|militar|verde_escuro/i.test(productColor) || colorHex && colorHex === "#000000" || (prompt.toLowerCase().includes("tecido escuro") || prompt.toLowerCase().includes("fundo escuro"));
      let finalPrompt = `Pure standalone 2D vector graphic design decal sticker, isolated screenprint graphic illustration, sharp clean crisp contour edges, centered on solid flat vibrant green background #00FF00.
Subject: ${sanitizedSubject}
Style: High quality vector art, clean sharp lines, screenprint decal badge aesthetic, pure flat 2D graphic asset file only.`;
      if (isDark) {
        finalPrompt += `
Color Contrast: High-contrast bright vivid palette (pure white, cream, vibrant light tones, bold highlights) designed to pop with brilliant contrast on dark surfaces.`;
      }
      finalPrompt += `
Chroma Background: Pure solid flat uniform green #00FF00 background with sharp cutout edges, internal letter holes cut out showing continuous #00FF00 green.`;
      parts.push({ text: finalPrompt });
      const config = {};
      if (aspectRatio && ["1:1", "3:4", "4:3", "9:16", "16:9"].includes(aspectRatio)) {
        config.imageConfig = { aspectRatio };
      }
      const response = await generateWithFallback(
        ai,
        ["gemini-3.1-flash-lite-image", "gemini-3.1-flash-image"],
        { parts },
        Object.keys(config).length > 0 ? config : void 0
      );
      const candidates = response.candidates;
      if (!candidates || candidates.length === 0) {
        return res.status(500).json({ error: "Nenhum resultado gerado pela IA." });
      }
      const responseParts = candidates[0].content?.parts || [];
      let initialBuffer = null;
      let initialMime = "image/png";
      let responseText = "";
      for (const part of responseParts) {
        if (part.inlineData) {
          initialMime = part.inlineData.mimeType || "image/png";
          initialBuffer = Buffer.from(part.inlineData.data, "base64");
          break;
        } else if (part.text) {
          responseText += part.text;
        }
      }
      if (!initialBuffer) {
        return res.status(500).json({
          error: responseText || "O Gemini n\xE3o retornou uma imagem para esta solicita\xE7\xE3o."
        });
      }
      let finalBuffer = initialBuffer;
      let finalMime = initialMime;
      const garmentDetection = await detectGarmentInImage(ai, initialBuffer);
      if (garmentDetection.has_garment) {
        console.log("\u26A0\uFE0F Detectada silhueta de camiseta/roupa na imagem gerada. Executando auto-cura para isolar estampa:", garmentDetection.explanation);
        const healed = await isolatePrintGraphicFromGarment(ai, initialBuffer, garmentDetection.print_bbox_normalized_1000);
        if (healed) {
          console.log("\u2705 Auto-cura bem sucedida: estampa isolada com perfei\xE7\xE3o sem camiseta!");
          finalBuffer = healed.buffer;
          finalMime = healed.mimeType;
        }
      }
      const ext = finalMime.includes("jpeg") || finalMime.includes("jpg") ? "jpg" : "png";
      const filename = `gemini-gen-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${ext}`;
      const filePath = import_path2.default.join(UPLOADS_DIR, filename);
      await import_fs2.default.promises.writeFile(filePath, finalBuffer);
      const generatedUrl = `/uploads/${filename}`;
      res.json({
        url: generatedUrl,
        mime_type: "image/png",
        garment_corrected: garmentDetection.has_garment
      });
    } catch (err) {
      console.error("Erro na gera\xE7\xE3o de imagem com Gemini:", err);
      const errorMessage = err.message || "";
      if (errorMessage.includes("RESOURCE_EXHAUSTED") || errorMessage.includes("Quota exceeded") || errorMessage.includes("429")) {
        return res.status(429).json({
          error: "Limite de cota atingido para gera\xE7\xE3o de imagens. Verifique se o seu projeto possui acesso aos modelos de imagem do Gemini."
        });
      }
      res.status(500).json({ error: errorMessage || "Erro ao gerar imagem com Gemini." });
    }
  });
  const reconstructRoutes = [
    "/api/gemini/reconstruct-artwork",
    "/api/apps/:appId/integration-endpoints/Core/ReconstructArtwork",
    "/apps/:appId/integration-endpoints/Core/ReconstructArtwork",
    "/integration-endpoints/Core/ReconstructArtwork"
  ];
  app.post(reconstructRoutes, async (req, res) => {
    try {
      const { image_url, base64_image, instructions, style, productColor, colorName } = req.body;
      const targetSource = image_url || base64_image;
      if (!targetSource) {
        return res.status(400).json({ error: "\xC9 necess\xE1rio fornecer a imagem para reconstru\xE7\xE3o (image_url ou base64_image)." });
      }
      const imgPart = await resolveImagePart(targetSource);
      if (!imgPart) {
        return res.status(400).json({ error: "N\xE3o foi poss\xEDvel carregar a imagem de origem para reconstru\xE7\xE3o." });
      }
      const ai = getGenAIClient();
      const parts = [
        {
          inlineData: {
            data: imgPart.data,
            mimeType: imgPart.mimeType
          }
        }
      ];
      const isDarkFabric = colorName && /black|preto|preta|navy|marinho|dark|escuro|wine|vinho/i.test(colorName) || productColor && /black|preto|preta|navy|marinho|dark|escuro|wine|vinho/i.test(productColor);
      let prompt = `You are a master digital illustrator, typography artisan, and professional DTG/DTF textile print production expert.

TASK: Reconstruct, upscale, and remaster the attached reference artwork into a crystal-clear, ultra-sharp, high-resolution master graphic for large apparel printing (300 DPI equivalent).

CRITICAL REQUIREMENTS:
1. SUBJECT & FIDELITY: Faithfully preserve the exact character, subject, typography, illustration details, and aesthetic essence of the user's reference image.
2. RESOLUTION & CLARITY: Eliminate all blurriness, pixelation, low-resolution artifacts, compression noise, and muddy lines. Rebuild with crisp vector-like outlines, clean curves, and vibrant, rich colors.
3. CHROMA KEY ISOLATION: Place the entire artwork cleanly isolated on a flat, solid, vivid green background (#00FF00 green screen). The background MUST be completely plain green so it can be flawlessly cut out for transparent DTG printing.
4. NO MOCKUPS: Do NOT place the artwork on a t-shirt, model, mannequin, or hanger. Render ONLY the flat, isolated graphic on the solid green #00FF00 background.
5. NO BORDERS: Do NOT add white borders, sticker outlines, or frames unless they are an intrinsic part of the original design.`;
      if (isDarkFabric) {
        prompt += `
6. DARK FABRIC CONTRAST: Ensure texts and line art have strong luminosity and contrast suitable for dark/black apparel fabric.`;
      }
      if (instructions) {
        prompt += `
USER SPECIFIC INSTRUCTIONS: ${instructions}`;
      }
      if (style) {
        prompt += `
STYLE EMPHASIS: ${style}`;
      }
      parts.push({ text: prompt });
      const response = await generateWithFallback(
        ai,
        ["gemini-3.1-flash-image", "gemini-3.1-flash-lite-image"],
        { parts }
      );
      const candidates = response.candidates;
      if (!candidates || candidates.length === 0) {
        return res.status(500).json({ error: "A IA n\xE3o conseguiu gerar a reconstru\xE7\xE3o desta imagem." });
      }
      const responseParts = candidates[0].content?.parts || [];
      let generatedUrl = "";
      let responseText = "";
      for (const part of responseParts) {
        if (part.inlineData) {
          const mime = part.inlineData.mimeType || "image/png";
          const ext = mime.includes("jpeg") ? "jpg" : "png";
          const filename = `gemini-reconstructed-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${ext}`;
          const filePath = import_path2.default.join(UPLOADS_DIR, filename);
          await import_fs2.default.promises.writeFile(filePath, Buffer.from(part.inlineData.data, "base64"));
          generatedUrl = `/uploads/${filename}`;
        } else if (part.text) {
          responseText += part.text;
        }
      }
      if (!generatedUrl) {
        return res.status(500).json({
          error: responseText || "O modelo de IA n\xE3o retornou uma imagem para a reconstru\xE7\xE3o."
        });
      }
      res.json({
        success: true,
        url: generatedUrl,
        reconstructed_url: generatedUrl,
        mime_type: "image/png",
        message: "Arte reconstru\xEDda com sucesso em alta defini\xE7\xE3o!"
      });
    } catch (err) {
      console.error("Erro na reconstru\xE7\xE3o de arte com Gemini:", err);
      const errorMessage = err.message || "";
      if (errorMessage.includes("RESOURCE_EXHAUSTED") || errorMessage.includes("Quota exceeded") || errorMessage.includes("429")) {
        return res.status(429).json({
          error: "Limite de cota de IA temporariamente atingido. Voc\xEA pode usar a Amplia\xE7\xE3o R\xE1pida HD instant\xE2nea!"
        });
      }
      res.status(500).json({ error: errorMessage || "Erro ao reconstruir arte com IA." });
    }
  });
  const llmRoutes = [
    "/api/gemini/invoke-llm",
    "/api/apps/:appId/integration-endpoints/Core/InvokeLLM",
    "/apps/:appId/integration-endpoints/Core/InvokeLLM",
    "/integration-endpoints/Core/InvokeLLM"
  ];
  app.post(llmRoutes, async (req, res) => {
    try {
      const { prompt, add_context_from_internet, response_json_schema, file_urls } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt \xE9 obrigat\xF3rio." });
      }
      const ai = getGenAIClient();
      const parts = [];
      if (Array.isArray(file_urls) && file_urls.length > 0) {
        for (const fileUrl of file_urls) {
          const imgPart = await resolveImagePart(fileUrl);
          if (imgPart) {
            parts.push({
              inlineData: {
                data: imgPart.data,
                mimeType: imgPart.mimeType
              }
            });
          }
        }
      }
      parts.push({ text: prompt });
      const config = {};
      if (response_json_schema) {
        config.responseMimeType = "application/json";
      }
      if (add_context_from_internet) {
        config.tools = [{ googleSearch: {} }];
      }
      const response = await generateWithFallback(
        ai,
        ["gemini-3.6-flash", "gemini-3.8-flash"],
        parts.length === 1 ? prompt : { parts },
        Object.keys(config).length > 0 ? config : void 0
      );
      const text = response.text || "";
      if (response_json_schema) {
        try {
          return res.json({ result: JSON.parse(text) });
        } catch {
          return res.json({ result: text });
        }
      }
      res.json({ result: text });
    } catch (err) {
      console.error("Erro no InvokeLLM:", err);
      res.status(500).json({ error: err.message || "Erro ao consultar Gemini." });
    }
  });
  app.post("/api/gemini/enhance-prompt", async (req, res) => {
    try {
      const { prompt, productType, style, productColor, colorName } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt \xE9 obrigat\xF3rio." });
      }
      const isDark = colorName && /black|preto|preta|navy|marinho|dark|escuro|escura|wine|vinho|bordo|chumbo|militar|verde_escuro/i.test(colorName) || productColor && /black|preto|preta|navy|marinho|dark|escuro|escura|wine|vinho|bordo|chumbo|militar|verde_escuro/i.test(productColor);
      const ai = getGenAIClient();
      const systemInstruction = `Voc\xEA \xE9 um diretor de arte e designer gr\xE1fico especializado em estampas autorais da plataforma C\xE9u Criativa.
Sua miss\xE3o \xE9 transformar a ideia do usu\xE1rio em uma descri\xE7\xE3o rica, art\xEDstica e detalhada, pronta para gerar uma estampa visualmente impactante.
${isDark ? "ATEN\xC7\xC3O DE CONTRASTE: Como a estampa ser\xE1 impressa sobre tecido escuro/preto, especifique que lettering, tipografia, tra\xE7os e ilustra\xE7\xF5es usem cores claras e luminosas (branco, marfim, amarelo claro, cores past\xE9is brilhantes) para alto contraste." : ""}
REGRA MANDAT\xD3RIA: Descreva ESTRITAMENTE a arte gr\xE1fica, ilustra\xE7\xE3o ou tipografia em si. NUNCA mencione roupas, camisetas, camisas, mangas, golas, modelos ou mockups, pois a IA deve desenhar apenas a estampa/desenho isolado e NUNCA uma camiseta.
Mantenha a resposta concisa (2 a 4 frases), em portugu\xEAs, com estilo visual claro, paleta de cores e elementos principais da arte gr\xE1fica.`;
      const userMessage = `Ideia da estampa: "${prompt}". Estilo desejado: "${style || "autoral e criativo"}".
Retorne apenas a vers\xE3o aprimorada da descri\xE7\xE3o da arte gr\xE1fica (sem citar camisetas ou roupas).`;
      const response = await generateWithFallback(
        ai,
        ["gemini-3.6-flash", "gemini-3.8-flash"],
        userMessage,
        {
          systemInstruction,
          temperature: 0.7
        }
      );
      res.json({ enhancedPrompt: response.text?.trim() || prompt });
    } catch (err) {
      console.error("Erro no enhance-prompt:", err);
      res.status(500).json({ error: err.message || "Erro ao aprimorar o prompt." });
    }
  });
  app.post("/api/gemini/generate-narration", async (req, res) => {
    try {
      const { title, description, prompt, category, artist_name } = req.body || {};
      const ai = getGenAIClient();
      const systemInstruction = `Voc\xEA \xE9 um curador de arte e contador de hist\xF3rias po\xE9tico da plataforma C\xE9u Criativa.
Sua miss\xE3o \xE9 criar uma narra\xE7\xE3o autoral cativante, po\xE9tica e emotiva (de 2 a 3 frases) para ser ouvida em \xE1udio pelas pessoas sobre a estampa do artista.
A narra\xE7\xE3o deve transmitir a ess\xEAncia visual, a emo\xE7\xE3o e o significado da estampa, conectando o p\xFAblico \xE0 arte.
Responda em portugu\xEAs brasileiro de forma fluida, inspiradora e pronta para leitura em voz alta.`;
      const userMessage = `Crie a narra\xE7\xE3o em \xE1udio para esta estampa:
T\xEDtulo: "${title || "Sem t\xEDtulo"}"
Conceito/Ideia: "${prompt || description || title || "Arte autoral"}"
Categoria: "${category || "Arte Visual"}"
Artista: "${artist_name || "Artista C\xE9u Criativa"}"

Retorne apenas o texto da narra\xE7\xE3o para ser lido em voz alta (sem introdu\xE7\xF5es como "Aqui est\xE1").`;
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: userMessage,
        config: {
          systemInstruction,
          temperature: 0.8
        }
      });
      const narration = response.text?.trim() || "";
      res.json({ narration });
    } catch (err) {
      console.error("Erro ao gerar narra\xE7\xE3o da estampa:", err);
      res.status(500).json({ error: err.message || "Erro ao gerar narra\xE7\xE3o." });
    }
  });
  app.post("/api/gemini/transcribe-audio", async (req, res) => {
    try {
      const { audioData, mimeType } = req.body || {};
      if (!audioData) {
        return res.status(400).json({ error: "Nenhum dado de \xE1udio fornecido." });
      }
      const ai = getGenAIClient();
      const rawBase64 = audioData.includes(",") ? audioData.split(",")[1] : audioData;
      const detectedMime = mimeType || (audioData.includes(";") ? audioData.split(";")[0].replace("data:", "") : "audio/webm");
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: [
          {
            inlineData: {
              mimeType: detectedMime.split(";")[0] || "audio/webm",
              data: rawBase64
            }
          },
          "Transcreva fielmente este \xE1udio falado em portugu\xEAs do Brasil. O usu\xE1rio est\xE1 narrando ou descrevendo uma estampa de camiseta ou arte autoral. Retorne APENAS o texto falado transcrito, sem aspas e sem nenhum coment\xE1rio."
        ]
      });
      const transcript = response.text?.trim() || "";
      res.json({ transcript });
    } catch (err) {
      console.error("Erro ao transcrever \xE1udio com Gemini:", err);
      res.status(500).json({ error: err.message || "Erro na transcri\xE7\xE3o de \xE1udio." });
    }
  });
  app.post("/api/cielo/checkout", async (req, res) => {
    try {
      const payload = req.body;
      if (!payload || !payload.paymentMethod || !payload.customer || !payload.shippingAddress) {
        return res.status(400).json({ error: "Dados incompletos para processamento com a Cielo." });
      }
      const orderNumber = `CEU-${Math.floor(1e5 + Math.random() * 9e5)}`;
      const cieloResult = await processCieloPayment(payload, orderNumber);
      if (!cieloResult.success && cieloResult.status === "denied") {
        return res.status(402).json({
          error: cieloResult.returnMessage || "Transa\xE7\xE3o n\xE3o autorizada pela Cielo.",
          cieloResult
        });
      }
      const createdOrder = entitiesStore.create("Order", {
        order_number: orderNumber,
        customer_name: payload.customer.name,
        customer_email: payload.customer.email,
        customer_cpf: payload.customer.cpf || "",
        customer_phone: payload.customer.phone || "",
        status: cieloResult.isApproved ? "paid" : "pending",
        payment_status: cieloResult.status,
        payment_method: payload.paymentMethod,
        payment_gateway: "cielo_3.0",
        cielo_payment_id: cieloResult.paymentId,
        cielo_tid: cieloResult.tid || "",
        cielo_auth_code: cieloResult.authCode || "",
        cielo_proof_of_sale: cieloResult.proofOfSale || "",
        cielo_return_code: cieloResult.returnCode || "",
        cielo_return_message: cieloResult.returnMessage || "",
        card_brand: cieloResult.cardBrand || payload.card?.brand || "",
        card_last4: cieloResult.cardLast4 || (payload.card?.cardNumber ? payload.card.cardNumber.slice(-4) : ""),
        installments: payload.installments || 1,
        total_amount: payload.totalAmount,
        items: payload.items || [],
        shipping_address: payload.shippingAddress,
        created_date: (/* @__PURE__ */ new Date()).toISOString(),
        updated_date: (/* @__PURE__ */ new Date()).toISOString()
      });
      entitiesStore.updateMe({
        has_purchased_first_print: true,
        store_active: true,
        cpf: payload.customer?.cpf || entitiesStore.currentUser.cpf,
        phone: payload.customer?.phone || entitiesStore.currentUser.phone
      });
      const userDesigns = entitiesStore.list("Design").filter((d) => d.artist_id === entitiesStore.currentUser.id);
      userDesigns.forEach((d) => {
        entitiesStore.update("Design", d.id, { status: "aprovado" });
      });
      res.json({
        success: true,
        order: createdOrder,
        cielo: cieloResult
      });
    } catch (err) {
      console.error("Erro no processamento Cielo:", err);
      res.status(500).json({ error: err.message || "Erro no gateway Cielo." });
    }
  });
  app.get("/api/cielo/order/:orderId", (req, res) => {
    try {
      const order = entitiesStore.get("Order", req.params.orderId) || entitiesStore.list("Order").find((o) => o.order_number === req.params.orderId);
      if (!order) return res.status(404).json({ error: "Pedido n\xE3o encontrado." });
      res.json(order);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/cielo/confirm-pix/:orderId", (req, res) => {
    try {
      const target = entitiesStore.get("Order", req.params.orderId) || entitiesStore.list("Order").find((o) => o.order_number === req.params.orderId);
      if (!target) return res.status(404).json({ error: "Pedido n\xE3o encontrado." });
      const updated = entitiesStore.update("Order", target.id, {
        status: "paid",
        payment_status: "approved",
        cielo_return_code: "00",
        cielo_return_message: "Pix confirmado com sucesso.",
        updated_date: (/* @__PURE__ */ new Date()).toISOString()
      });
      res.json({ success: true, order: updated });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/cielo/webhook", (req, res) => {
    try {
      const { PaymentId, ChangeType } = req.body || {};
      if (PaymentId) {
        const order = entitiesStore.list("Order").find((o) => o.cielo_payment_id === PaymentId);
        if (order) {
          entitiesStore.update("Order", order.id, {
            status: ChangeType === "1" ? "paid" : order.status,
            updated_date: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
      res.json({ received: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.get([
    "/apps/public/prod/public-settings/by-id/:appId",
    "/api/apps/public/prod/public-settings/by-id/:appId",
    "/prod/public-settings/by-id/:appId",
    "/apps/public/*all",
    "/api/apps/public/*all"
  ], (req, res) => {
    res.json({
      id: req.params.appId || "ceu-criativa",
      public_settings: {
        auth_required: false,
        name: "C\xE9u Criativa"
      }
    });
  });
  app.post([
    "/app-logs/:appId/log-user-in-app/:pageName",
    "/api/app-logs/:appId/log-user-in-app/:pageName",
    "/app-logs/*all",
    "/api/app-logs/*all"
  ], (_req, res) => {
    res.json({ success: true });
  });
  app.get([
    "/app-logs/:appId",
    "/api/app-logs/:appId",
    "/app-logs/:appId/stats",
    "/api/app-logs/:appId/stats",
    "/app-logs/*all",
    "/api/app-logs/*all"
  ], (_req, res) => {
    res.json({ logs: [], stats: {} });
  });
  app.post([
    "/apps/:appId/analytics/track/batch",
    "/api/apps/:appId/analytics/track/batch",
    "/apps/:appId/analytics/*all",
    "/api/apps/:appId/analytics/*all"
  ], (_req, res) => {
    res.json({ success: true, processed: true });
  });
  app.get([
    "/apps/:appId/external-auth/tokens/:type",
    "/api/apps/:appId/external-auth/tokens/:type",
    "/apps/:appId/external-auth/tokens/connectors/:id",
    "/api/apps/:appId/external-auth/tokens/connectors/:id",
    "/apps/:appId/external-auth/*all",
    "/api/apps/:appId/external-auth/*all"
  ], (_req, res) => {
    res.json({ access_token: "mock-token", connection_config: {} });
  });
  app.get([
    "/apps/:appId/users",
    "/api/apps/:appId/users",
    "/api/apps/:appId/runtime/users",
    "/api/users"
  ], (_req, res) => {
    res.json(entitiesStore.list("User", {}));
  });
  app.get([
    "/api/apps/:appId/entities/User/me",
    "/apps/:appId/entities/User/me",
    "/api/apps/:appId/auth/me",
    "/apps/:appId/auth/me",
    "/api/apps/auth/me",
    "/api/entities/User/me",
    "/api/auth/me"
  ], (_req, res) => {
    const user = { ...entitiesStore.currentUser };
    if (!user.name) user.name = user.full_name || "Felipe Silv\xE9rio";
    res.json(user);
  });
  app.put([
    "/api/apps/:appId/entities/User/me",
    "/apps/:appId/entities/User/me",
    "/api/entities/User/me"
  ], (req, res) => {
    const updated = entitiesStore.updateMe(req.body);
    res.json(updated);
  });
  const DEFAULT_INDUSTRY_FITS = [
    "Tradicional",
    "Regular Fit",
    "Oversized",
    "Streetwear Boxy",
    "Baby Look",
    "Slim Fit",
    "Raglan",
    "Regata",
    "Muscle Tee",
    "Gola V",
    "Moletom Canguru",
    "Moletom Careca",
    "Manga Longa",
    "Camisa Polo",
    "Cropped",
    "Infantil",
    "Longline",
    "Heavyweight Streetwear"
  ];
  app.get("/api/product-fits", (_req, res) => {
    try {
      const coll = entitiesStore.getCollection("ProductFit");
      if (coll.length === 0) {
        DEFAULT_INDUSTRY_FITS.forEach((name) => {
          entitiesStore.create("ProductFit", { name, is_default: true });
        });
      }
      const allFits = entitiesStore.getCollection("ProductFit");
      const products = entitiesStore.getCollection("Product") || [];
      const productFits = products.map((p) => p.fit).filter(Boolean);
      const fitNames = Array.from(/* @__PURE__ */ new Set([
        ...allFits.map((f) => f.name),
        ...productFits,
        ...DEFAULT_INDUSTRY_FITS
      ])).filter(Boolean);
      res.json(fitNames);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/product-fits", (req, res) => {
    try {
      const rawName = (req.body?.name || req.body?.fit || "").trim();
      if (!rawName) return res.status(400).json({ error: "Nome da modelagem \xE9 obrigat\xF3rio" });
      const coll = entitiesStore.getCollection("ProductFit");
      const exists = coll.some((f) => f.name?.toLowerCase() === rawName.toLowerCase());
      let created = null;
      if (!exists) {
        created = entitiesStore.create("ProductFit", { name: rawName, is_default: false });
      }
      const allFits = Array.from(/* @__PURE__ */ new Set([
        ...entitiesStore.getCollection("ProductFit").map((f) => f.name),
        ...DEFAULT_INDUSTRY_FITS
      ]));
      res.json({ success: true, created, fits: allFits, name: rawName });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/inventory/overview", (_req, res) => {
    try {
      const products = entitiesStore.list("Product", { q: { catalog_product: true } });
      const variants = entitiesStore.getCollection("BaseProductVariant") || [];
      const productsWithGrid = products.map((prod) => {
        const prodVariants = variants.filter((v) => String(v.base_product_id) === String(prod.id));
        const colors = prod.colors_available || [];
        const sizes = prod.sizes_available || [];
        const possibleCombinations = [];
        colors.forEach((color) => {
          sizes.forEach((size) => {
            const existing = prodVariants.find((v) => v.color?.toLowerCase() === color.toLowerCase() && v.size?.toLowerCase() === size.toLowerCase());
            possibleCombinations.push({
              color,
              size,
              exists: !!existing,
              variant: existing || null
            });
          });
        });
        return {
          ...prod,
          variants: prodVariants,
          total_stock: prodVariants.reduce((sum, v) => sum + (Number(v.stock_quantity) || 0), 0),
          combinations: possibleCombinations,
          missing_count: possibleCombinations.filter((c) => !c.exists).length
        };
      });
      const totalUnits = variants.reduce((sum, v) => sum + (Number(v.stock_quantity) || 0), 0);
      const zeroStockCount = variants.filter((v) => (Number(v.stock_quantity) || 0) <= 0).length;
      res.json({
        products: productsWithGrid,
        variants,
        metrics: {
          total_products: products.length,
          total_variants: variants.length,
          total_units: totalUnits,
          zero_stock_variants: zeroStockCount
        }
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/inventory/bulk-update", (req, res) => {
    try {
      const { variantIds, action, quantity, isActive } = req.body || {};
      if (!Array.isArray(variantIds) || variantIds.length === 0) {
        return res.status(400).json({ error: "Nenhuma varia\xE7\xE3o selecionada." });
      }
      const variants = entitiesStore.getCollection("BaseProductVariant");
      const updatedList = [];
      variantIds.forEach((id) => {
        const variant = variants.find((v) => String(v.id) === String(id));
        if (!variant) return;
        const currentQty = Number(variant.stock_quantity) || 0;
        let newQty = currentQty;
        if (action === "set") {
          newQty = Math.max(0, Number(quantity) || 0);
        } else if (action === "add") {
          newQty = Math.max(0, currentQty + (Number(quantity) || 0));
        } else if (action === "subtract") {
          newQty = Math.max(0, currentQty - (Number(quantity) || 0));
        } else if (action === "zero") {
          newQty = 0;
        }
        const patch = { stock_quantity: newQty };
        if (isActive !== void 0) {
          patch.is_active = Boolean(isActive);
        }
        const updated = entitiesStore.update("BaseProductVariant", variant.id, patch);
        if (updated) updatedList.push(updated);
      });
      res.json({ success: true, count: updatedList.length, updated: updatedList });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/inventory/generate-grid", (req, res) => {
    try {
      const { productId, defaultStock = 0 } = req.body || {};
      if (!productId) return res.status(400).json({ error: "ID do produto \xE9 obrigat\xF3rio" });
      const product = entitiesStore.get("Product", productId);
      if (!product) return res.status(404).json({ error: "Produto n\xE3o encontrado" });
      const colors = product.colors_available || [];
      const sizes = product.sizes_available || [];
      const variants = entitiesStore.getCollection("BaseProductVariant");
      const createdList = [];
      const stock = Math.max(0, Number(defaultStock) || 0);
      colors.forEach((color) => {
        sizes.forEach((size) => {
          const exists = variants.some(
            (v) => String(v.base_product_id) === String(productId) && v.color?.toLowerCase() === color.toLowerCase() && v.size?.toLowerCase() === size.toLowerCase()
          );
          if (!exists) {
            const created = entitiesStore.create("BaseProductVariant", {
              base_product_id: productId,
              color,
              size,
              stock_quantity: stock,
              is_active: true,
              debited_order_ids: [],
              released_order_ids: []
            });
            createdList.push(created);
          }
        });
      });
      res.json({ success: true, count: createdList.length, created: createdList });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.all([
    "/api/apps/:appId/entities/:entityName/update-many",
    "/apps/:appId/entities/:entityName/update-many",
    "/api/entities/:entityName/update-many"
  ], (req, res) => {
    try {
      const { ids, data } = req.body || {};
      if (Array.isArray(ids) && data && typeof data === "object") {
        const updated = ids.map((id) => entitiesStore.update(req.params.entityName, id, data));
        return res.json({ success: true, count: updated.length, items: updated });
      }
      res.json({ success: true, count: 0 });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post([
    "/api/apps/:appId/entities/:entityName/bulk",
    "/apps/:appId/entities/:entityName/bulk",
    "/api/entities/:entityName/bulk"
  ], (req, res) => {
    try {
      const items = Array.isArray(req.body) ? req.body : [];
      const created = items.map((item) => entitiesStore.create(req.params.entityName, item));
      res.json(created);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.put([
    "/api/apps/:appId/entities/:entityName/bulk",
    "/apps/:appId/entities/:entityName/bulk",
    "/api/entities/:entityName/bulk"
  ], (req, res) => {
    try {
      const items = Array.isArray(req.body) ? req.body : [];
      const updated = items.map((item) => entitiesStore.update(req.params.entityName, item.id, item));
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.all([
    "/api/apps/:appId/entities/:entityName/delete-many",
    "/apps/:appId/entities/:entityName/delete-many",
    "/api/entities/:entityName/delete-many",
    "/api/apps/:appId/entities/:entityName/bulk-delete",
    "/apps/:appId/entities/:entityName/bulk-delete",
    "/api/entities/:entityName/bulk-delete"
  ], (req, res) => {
    try {
      const count = entitiesStore.deleteMany(req.params.entityName, req.body);
      res.json({ success: true, count });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.get([
    "/api/apps/:appId/entities/:entityName",
    "/apps/:appId/entities/:entityName",
    "/api/entities/:entityName"
  ], (req, res) => {
    try {
      const entityName = req.params.entityName;
      let q = void 0;
      if (req.query.q) {
        try {
          q = JSON.parse(req.query.q);
        } catch {
        }
      } else if (req.query.filter) {
        try {
          q = typeof req.query.filter === "string" ? JSON.parse(req.query.filter) : req.query.filter;
        } catch {
        }
      }
      const specialKeys = /* @__PURE__ */ new Set(["q", "filter", "sort", "limit", "skip", "fields", "appId"]);
      const directFilters = {};
      for (const [key, val] of Object.entries(req.query)) {
        if (!specialKeys.has(key) && val !== void 0) {
          directFilters[key] = val;
        }
      }
      if (Object.keys(directFilters).length > 0) {
        q = { ...q || {}, ...directFilters };
      }
      const sort = req.query.sort;
      const limit = req.query.limit ? parseInt(req.query.limit, 10) : void 0;
      const skip = req.query.skip ? parseInt(req.query.skip, 10) : void 0;
      const results = entitiesStore.list(entityName, { q, sort, limit, skip });
      res.json(results);
    } catch (err) {
      console.error("Erro ao listar entidade:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.get([
    "/api/apps/:appId/entities/:entityName/:id",
    "/apps/:appId/entities/:entityName/:id",
    "/api/entities/:entityName/:id"
  ], (req, res) => {
    const item = entitiesStore.get(req.params.entityName, req.params.id);
    if (!item) {
      return res.status(404).json({ error: "Item n\xE3o encontrado." });
    }
    res.json(item);
  });
  app.post([
    "/api/apps/:appId/entities/:entityName",
    "/apps/:appId/entities/:entityName",
    "/api/entities/:entityName"
  ], (req, res) => {
    try {
      const created = entitiesStore.create(req.params.entityName, req.body);
      res.json(created);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.put([
    "/api/apps/:appId/entities/:entityName/:id",
    "/apps/:appId/entities/:entityName/:id",
    "/api/entities/:entityName/:id"
  ], (req, res) => {
    try {
      const updated = entitiesStore.update(req.params.entityName, req.params.id, req.body);
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.delete([
    "/api/apps/:appId/entities/:entityName/:id",
    "/apps/:appId/entities/:entityName/:id",
    "/api/entities/:entityName/:id"
  ], (req, res) => {
    const success = entitiesStore.delete(req.params.entityName, req.params.id);
    res.json({ success });
  });
  app.delete([
    "/api/apps/:appId/entities/:entityName",
    "/apps/:appId/entities/:entityName",
    "/api/entities/:entityName"
  ], (req, res) => {
    const count = entitiesStore.deleteMany(req.params.entityName, req.body);
    res.json({ success: true, count });
  });
  app.post([
    "/api/apps/:appId/users/invite-user",
    "/apps/:appId/users/invite-user",
    "/api/apps/:appId/runtime/users/invite-user"
  ], (_req, res) => {
    res.json({ success: true, message: "Convite registrado." });
  });
  app.post([
    "/apps/:appId/functions/:functionName",
    "/api/apps/:appId/functions/:functionName",
    "/api/functions/:functionName",
    "/functions/:functionName"
  ], (_req, res) => {
    res.json({ ok: true, result: {} });
  });
  app.all([
    "/apps/:appId/*all",
    "/api/apps/*all",
    "/app-logs/*all",
    "/api/app-logs/*all"
  ], (req, res) => {
    if (req.method === "GET") {
      res.json([]);
    } else {
      res.json({ success: true });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path2.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*all", (_req, res) => {
      res.sendFile(import_path2.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
